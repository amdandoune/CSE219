/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.file;

import cc.CodeCheckApp;
import djf.components.AppDataComponent;
import djf.components.AppFileComponent;
import java.io.IOException;

/**
 *
 * @author Lenovo
 */
public class CodeCheckFiles implements AppFileComponent {
    // THIS IS THE APP ITSELF
    CodeCheckApp app;
    
    // THESE ARE USED FOR IDENTIFYING JSON TYPES
    static final String JSON_SLIDESHOWTITLE = "slide_show_title";
    static final String JSON_SLIDES = "slides";
    static final String JSON_SLIDE = "slide";
    static final String JSON_FILE_NAME = "file_name";
    static final String JSON_PATH = "path";
    static final String JSON_CAPTION = "caption";
    static final String JSON_ORIGINAL_WIDTH = "original_width";
    static final String JSON_ORIGINAL_HEIGHT = "original_height";
    static final String JSON_CURRENT_WIDTH = "current_width";
    static final String JSON_CURRENT_HEIGHT = "current_height";
    static final String JSON_POSITION_X = "position_x";
    static final String JSON_POSITION_Y = "position_y";
    
    
    public CodeCheckFiles(CodeCheckApp initApp) {
        app = initApp;
    }

    @Override
    public void saveData(AppDataComponent data, String filePath) throws IOException {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void loadData(AppDataComponent data, String filePath) throws IOException {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void exportData(AppDataComponent data, String filePath) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void importData(AppDataComponent data, String filePath) throws IOException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
