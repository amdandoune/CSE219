/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.style;

/**
 *
 * @author Lenovo
 */
public class CodeCheckStyle {
    // WE'LL USE THIS FOR ORGANIZING LEFT AND RIGHT CONTROLS
    public static String CLASS_SLIDES_TABLE = "slides_table";
    public static String CLASS_PROMPT_LABEL = "prompt_label";
    public static String CLASS_EDIT_TEXT_FIELD = "edit_text_field";
    public static String CLASS_EDIT_SLIDER = "edit_slider";
    public static String CLASS_EDIT_BUTTON = "edit_button";
    public static String CLASS_UPDATE_BUTTON = "update_button";
    public static String CLASS_IMAGE_BUTTON = "image_button";
}
