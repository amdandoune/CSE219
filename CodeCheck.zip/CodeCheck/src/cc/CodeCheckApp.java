/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc;

import cc.data.CodeCheckData;
import cc.file.CodeCheckFiles;
import cc.workspace.CodeCheckWorkspace;
import java.util.Locale;
import static javafx.application.Application.launch;
import djf.AppTemplate;

/**
 *
 * @author Lenovo
 */
public class CodeCheckApp extends AppTemplate {
    
    
     @Override
    public void buildAppComponentsHook() {
        // CONSTRUCT ALL FOUR COMPONENTS. NOTE THAT FOR THIS APP
        // THE WORKSPACE NEEDS THE DATA COMPONENT TO EXIST ALREADY
        // WHEN IT IS CONSTRUCTED, SO BE CAREFUL OF THE ORDER
        dataComponent = new CodeCheckData(this);
        workspaceComponent = new CodeCheckWorkspace(this);
        fileComponent = new CodeCheckFiles(this);
    }
    
    public static void main(String[] args) {
	Locale.setDefault(Locale.US);
	launch(args);
    }
    
}
