/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.workspace;

import cc.CodeCheckApp;
import cc.data.CodeCheckData;
import cc.data.Setter;

import djf.components.AppDataComponent;
import djf.components.AppWorkspaceComponent;
import static djf.settings.AppStartupConstants.FILE_PROTOCOL;
import static djf.settings.AppStartupConstants.PATH_IMAGES;
import static djf.ui.AppGUI.CLASS_BORDERED_PANE;
import properties_manager.PropertiesManager;

import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import static cc.style.CodeCheckStyle.CLASS_EDIT_BUTTON;
import static cc.style.CodeCheckStyle.CLASS_EDIT_TEXT_FIELD;
import static cc.style.CodeCheckStyle.CLASS_PROMPT_LABEL;
import static cc.style.CodeCheckStyle.CLASS_SLIDES_TABLE;
import java.io.File;
import javafx.geometry.Insets;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.GridPane;

/**
 *
 * @author Lenovo
 */
public class CodeCheckWorkspace extends AppWorkspaceComponent {
    
     // THIS PROVIDES US WITH ACCESS TO THE APP COMPONENTS
    CodeCheckApp app;

    // THIS PROVIDES RESPONSES TO INTERACTIONS WITH THIS WORKSPACE
    CodeCheckController controller;
    
    Button closeButton;
    Hyperlink newHyperlink;
    Hyperlink loadHyperlink; 
    Button newButton;
    Button loadButton;
    Button renameButton;
    Button aboutButton;

    Button homeButton;
    Button previousButton;
    Button nextButton; 
    
    Button removeButton;
    Button refreshButton;
    Button viewButton;

    Button extractButton;
    Button rename2Button;
    Button unzipButton;
    Button extractCodeButton;
    Button codeCheckButton;
    Button viewResultButton;

    Label stepLabel;
    Label progressLabel;
    Label barProgress;
    Label tableViewLabel;

    Label sourceFileLabel;
//    Label SFT1Label;
//    Label SFT2Label;
//    Label SFT3Label;
//    Label SFT4Label;
    TextField SFT5Text;

    CheckBox SFT1CheckBox;
    CheckBox SFT2CheckBox;
    CheckBox SFT3CheckBox;
    CheckBox SFT4CheckBox;
    CheckBox SFT5CheckBox;
    
    ScrollPane tablePane;
    ScrollPane detailPane;
    TableView<Setter> table;
    TableColumn<Setter, StringProperty> fileNameColumn;
    TextArea progressDetails;
    ProgressBar bar;

    BorderPane mainPane;
    HBox topBar;
    HBox fileToolBar;
    HBox editToolBar;
    HBox tableViewToolBar;
    VBox topToolBar;
    VBox scroolSide;
    HBox hb1;
    HBox hb2;
    HBox hb3;
    VBox vb1;
    
    GridPane checkPane;
    GridPane stepPane;
    int i;
    
    /**
     * The constructor initializes the user interface for the
     * workspace area of the application.
     */
    public CodeCheckWorkspace(CodeCheckApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;

        // WE'LL NEED THIS TO GET LANGUAGE PROPERTIES FOR OUR UI
        PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        // LAYOUT THE APP
        initLayout();
        
        // HOOK UP THE CONTROLLERS
        initControllers();
        
        // AND INIT THE STYLE FOR THE WORKSPACE
        initStyle();
    }
    
    private void initLayout() {
        // FileToolBar
        fileToolBar = new HBox();
        newButton = new Button("New");
        loadButton = new Button("Load");
        renameButton = new Button("Rename");
        aboutButton = new Button("About");
        fileToolBar.getChildren().addAll(newButton, loadButton, renameButton, aboutButton);
        
        // EditToolBar
        editToolBar = new HBox();
        homeButton = new Button("Home");
        previousButton = new Button("Previous");
        nextButton = new Button("Next"); 
        editToolBar.getChildren().addAll(homeButton, previousButton, nextButton);
        
        // tableViewToolBar
        tableViewToolBar = new HBox();
        removeButton = new Button("Remove");
        refreshButton = new Button("Refresh");
        viewButton = new Button("View");
        tableViewToolBar.getChildren().addAll(removeButton, refreshButton, viewButton);
        
        // topBar
        topBar = new HBox();
        topBar.getChildren().addAll(fileToolBar, editToolBar);
        
        // updateButton ToolBar
        extractButton = new Button("Extract");
        rename2Button = new Button("Rename");
        unzipButton = new Button("Unzip");
        extractCodeButton = new Button("Extract Code");
        codeCheckButton = new Button("Code Check");
        viewResultButton = new Button("View Resuts");
        hb3 = new HBox();
        hb3.getChildren().addAll(codeCheckButton, viewResultButton);
        
        // Label's settings
        stepLabel = new Label();
        progressLabel = new Label();
        barProgress = new Label("0 %");
//        bar.setProgress(0);
        barProgress.setTranslateX(15);
        barProgress.setTranslateY(25);
        bar = new ProgressBar(0);
        bar.setTranslateY(25);

        hb2 = new HBox();
        hb2.getChildren().addAll(progressLabel, bar, barProgress);
        tableViewLabel = new Label();

        stepPane = new GridPane();
        stepPane.add(stepLabel, 0, 0);
        stepPane.add(hb2, 1, 0);
        stepPane.add(tableViewLabel , 0, 1);
        stepPane.add(extractButton, 1, 1); 
        
        // topToolBar
        topToolBar = new VBox();
        topToolBar.getChildren().addAll(topBar, stepPane);
        
        
        checkPane = new GridPane();
        
        sourceFileLabel = new Label("Source File Types");
        SFT1CheckBox = new CheckBox(".java");
        SFT2CheckBox = new CheckBox(".js");
        SFT3CheckBox = new CheckBox(".c, .h, .cpp");
        SFT4CheckBox = new CheckBox(".cs");
        
        SFT5CheckBox = new CheckBox();
        SFT5Text = new TextField();
//        SFT5Text.setPrefHeight(80);
        hb1 = new HBox();
        hb1.getChildren().addAll(SFT5CheckBox, SFT5Text);
        
        checkPane.add(sourceFileLabel, 0, 0);
        checkPane.add(SFT1CheckBox, 0, 1);
        checkPane.add(SFT2CheckBox, 1, 1);
        checkPane.add(SFT3CheckBox, 0, 2);
        checkPane.add(SFT4CheckBox, 1, 2);
        checkPane.add(hb1,0 ,3);
        
        // scroll
        tablePane = new ScrollPane();
        table = new TableView();
        fileNameColumn = new TableColumn(); // props.getProperty(FILE_NAME_COLUMN_TEXT)
        table.getColumns().add(fileNameColumn);
        fileNameColumn.prefWidthProperty().bind(table.widthProperty().divide(1));
        fileNameColumn.setCellValueFactory(
                new PropertyValueFactory<Setter, StringProperty>("fileName") // fileName is a variable in Setter
        );
        
        // HOOK UP THE TABLE TO THE DATA
        CodeCheckData data = (CodeCheckData)app.getDataComponent();
        ObservableList<Setter> model = data.getSetter();
        table.setItems(model);
        tablePane.setContent(table);
        
//        tableViewToolBar
        vb1 = new VBox();
        vb1.getChildren().addAll(tablePane, tableViewToolBar);
        
        
        detailPane = new ScrollPane();
        progressDetails = new TextArea();
        detailPane.setContent(progressDetails);
        
        i = 1;
        setStep(i);
        
        
         // AND THEN PUT EVERYTHING INSIDE THE WORKSPACE
         app.getGUI().getTopToolbarPane().getChildren().remove(0);
//        app.getGUI().getTopToolbarPane().getChildren().add(topToolBar);//addAll(fileToolBar, editToolBar); // add fileToolBar & editToolBar
//        app.getGUI().getAppPane().setCenter(tablePane);
        BorderPane workspaceBorderPane = new BorderPane();
        workspaceBorderPane.setTop(topToolBar);
        workspaceBorderPane.setCenter(vb1);
        tablePane.setFitToWidth(true);
        tablePane.setFitToHeight(true);
//        table.setOnMouseClicked(e -> {
//            controller.handleSelected();
//        });
        workspaceBorderPane.setRight(detailPane);
        
        // AND SET THIS AS THE WORKSPACE PANE
        workspace = workspaceBorderPane;
    }
    
    private void initControllers() {
        // NOW LET'S SETUP THE EVENT HANDLING
        
        // NOW LET'S SETUP THE EVENT HANDLING
        controller = new CodeCheckController(app);
        ///////////
        app.getGUI().getFileController().isSaved();
        
        app.getGUI().getNewLink().setOnMouseReleased(e->{
            controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
        });
        app.getGUI().getLoadLink().setOnMouseReleased(e->{
            controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
        });
        
        newButton.setOnAction(e->{
            controller.handleNew();
            controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
        });
        loadButton.setOnAction(e->{
            controller.handleLoad();
            controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
        });
        renameButton.setOnAction(e->{
            controller.handleRenameFolder();
        });
        aboutButton.setOnAction(e->{
            controller.handleAbout();
        });
        
        homeButton.setOnAction(e->{
            i = 1;
            setStep(i);
            controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
        });
        previousButton.setOnAction(e->{
            setStep(--i);
            if(i == 1){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
            }
            else if(i == 2 || i == 3){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\submissions");
            }
            else if(i == 4){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\projects");
            }
            else if(i == 5){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\code");
            }
//            controller.displayFileName(i);
//            controller.handlePrevious();
        });
        nextButton.setOnAction(e->{
            setStep(++i);
            if(i == 1){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
            }
            else if(i == 2 || i == 3){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\submissions");
            }
            else if(i == 4){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\projects");
            }
            else if(i == 5){
                controller.displayFileName(controller.fileController.getWorkFolder().getAbsolutePath()+"\\code");
            }
//            controller.displayFileName(i);
//            controller.handleNext();
        });
        
        removeButton.setOnAction(e->{
            controller.handleRemove();
            
            table.getSelectionModel().clearSelection();
            removeButton.setDisable(true);
//            refreshButton.setDisable(true);
            viewButton.setDisable(true);
        });
        refreshButton.setOnAction(e->{
            controller.handleRefresh();
            
            table.getSelectionModel().clearSelection();
            removeButton.setDisable(true);
//            refreshButton.setDisable(true);
            viewButton.setDisable(true);
        });
        viewButton.setOnAction(e->{
            controller.handleView();
        });

        extractButton.setOnAction(e->{
            controller.handleExtract();
            
            table.getSelectionModel().clearSelection();
            extractButton.setDisable(true);
            removeButton.setDisable(true);
//            refreshButton.setDisable(true);
            viewButton.setDisable(true);
        });
        rename2Button.setOnAction(e->{
            controller.handleRenameFile();
            
            table.getSelectionModel().clearSelection();
            rename2Button.setDisable(true);
            removeButton.setDisable(true);
//            refreshButton.setDisable(true);
            viewButton.setDisable(true);
        });
        unzipButton.setOnAction(e->{
            controller.handleUnzip();
            
            table.getSelectionModel().clearSelection();
            unzipButton.setDisable(true);
            removeButton.setDisable(true);
//            refreshButton.setDisable(true);
            viewButton.setDisable(true);
        });
        extractCodeButton.setOnAction(e->{
            controller.handleExtractCode();
            
            table.getSelectionModel().clearSelection();
            extractCodeButton.setDisable(true);
            removeButton.setDisable(true);
//            refreshButton.setDisable(true);
            viewButton.setDisable(true);
        });
        codeCheckButton.setOnAction(e->{
            controller.handleCodeCheck();
        });
        viewResultButton.setOnAction(e->{
            controller.handleViewResults();
        });
        
        SFT5Text.setOnAction(e->{
//            controller.handleAddAllImagesInDirectory();
        });
        
    }
    
    // WE'LL PROVIDE AN ACCESSOR METHOD FOR EACH VISIBLE COMPONENT
    // IN CASE A CONTROLLER OR STYLE CLASS NEEDS TO CHANGE IT
    
    private void initStyle() {
        
        fileToolBar.getStyleClass().add(CLASS_BORDERED_PANE);
        newButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        loadButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        renameButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        aboutButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        
        editToolBar.getStyleClass().add(CLASS_BORDERED_PANE);
        homeButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        previousButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        nextButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        
//        tableViewToolBar.getStyleClass().add(CLASS_BORDERED_PANE);
        removeButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        refreshButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        viewButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        
//        topBar.getStyleClass().add(CLASS_BORDERED_PANE);
        
        extractButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        rename2Button.getStyleClass().add(CLASS_EDIT_BUTTON);
        unzipButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        extractCodeButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        codeCheckButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        viewResultButton.getStyleClass().add(CLASS_EDIT_BUTTON);
        
        // Label's settings
        stepLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        progressLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        tableViewLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
        
        // topBar
        topBar.getStyleClass().add(CLASS_BORDERED_PANE);
        
        SFT5Text.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
        
        // THE SLIDES TABLE
        table.getStyleClass().add(CLASS_SLIDES_TABLE);
        for (TableColumn tc : table.getColumns())
            tc.getStyleClass().add(CLASS_SLIDES_TABLE);
        
//         editImagesToolbar.getStyleClass().add(CLASS_BORDERED_PANE);
//        
//        addAllImagesInDirectoryButton.getStyleClass().add(CLASS_EDIT_BUTTON);
//        
//        // THE SLIDES TABLE
//        table.getStyleClass().add(CLASS_SLIDES_TABLE);
//        for (TableColumn tc : table.getColumns())
//            tc.getStyleClass().add(CLASS_SLIDES_TABLE);
//        
//        editPane.getStyleClass().add(CLASS_BORDERED_PANE);
//        fileNamePromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
//        
//        currentHeightPromptLabel.getStyleClass().add(CLASS_PROMPT_LABEL);
//        fileNameTextField.getStyleClass().add(CLASS_EDIT_TEXT_FIELD);
//        currentHeightSlider.getStyleClass().add(CLASS_EDIT_SLIDER); 
//        
//        slideImage.getStyleClass().add(CLASS_IMAGE_BUTTON);
        
    }

    @Override
    public void resetWorkspace() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void reloadWorkspace(AppDataComponent dataComponent) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void setStep(int i){
        
        extractButton.setDisable(true);
        rename2Button.setDisable(true);
        unzipButton.setDisable(true);
        extractCodeButton.setDisable(true);
        codeCheckButton.setDisable(true);
        viewResultButton.setDisable(true);
        
        removeButton.setDisable(true);
//        refreshButton.setDisable(true);
        viewButton.setDisable(true);
        
        progressDetails.setText("");
        barProgress.setText("0 %");
        bar.setProgress(0);
        if(i == 1){
            homeButton.setDisable(true);
            previousButton.setDisable(true);
            nextButton.setDisable(false);
//            extractButton.setDisable(false);
            
            stepLabel.setText("Step 1: Extract Submissions");
            progressLabel.setText("Extraction Progress ");
            tableViewLabel.setText("Select the submissions below from which to extract student work");
            stepPane.getChildren().remove(3);
            stepPane.add(extractButton, 1, 1);
            
            fileNameColumn.setText("Blackboard Submissions");
            
            if(vb1.getChildren().size() == 3){
                vb1.getChildren().remove(2);
            }
            table.setOnMouseClicked(e -> {
                controller.handleSelected();
            });
//            controller.displayFileName();
//            controller.handleAddDirectoryFiles();
//            TableSetting Display files in directory: work/assignment/blackboard
//            Extract will move selected files to directory: work/assignment/submissions
//            fileNameColumn.setCellValueFactory(
//                new PropertyValueFactory<Setter, StringProperty>("fileName")
//            );
        }
        else if(i == 2){
            homeButton.setDisable(false);
            previousButton.setDisable(false);
            nextButton.setDisable(false);
//            rename2Button.setDisable(false);
            
            stepLabel.setText("Step 2: Rename Student Submissions");
            progressLabel.setText("Rename Progress ");
            tableViewLabel.setText("Click the Rename button to rename all submissions ");
            stepPane.getChildren().remove(3);
            stepPane.add(rename2Button, 1, 1);
            
            fileNameColumn.setText("Student Submissions");
            
            if(vb1.getChildren().size() == 3){
                vb1.getChildren().remove(2);
            }
            table.setOnMouseClicked(e -> {
                controller.handleSelected();
            });
//            TableSetting Display files in directory: work/assignment/submissions
//            Rename selected files in directory: work/assignment/submissions
            
        }
        else if(i == 3){
            homeButton.setDisable(false);
            previousButton.setDisable(false);
            nextButton.setDisable(false);
//            unzipButton.setDisable(false);
            
            stepLabel.setText("Step 3: Unzip Student Submissions");
            progressLabel.setText("Unzip Progress ");
            tableViewLabel.setText("Select student submissions and click Unzip");
            stepPane.getChildren().remove(3);
            stepPane.add(unzipButton, 1, 1);
            
            fileNameColumn.setText("Student ZIP Files ");
            
            if(vb1.getChildren().size() == 3){
                vb1.getChildren().remove(2);
            }
            
//            TableSetting Display files in directory: work/assignment/submissions
//            Unzip selected files to directory: work/assignment/projects/NetID (one directory for each student)
        }
        else if(i == 4){
            homeButton.setDisable(false);
            previousButton.setDisable(false);
            nextButton.setDisable(false);
//            extractCodeButton.setDisable(false);
            
            stepLabel.setText("Step 4: Extract Source Code ");
            progressLabel.setText("Code Progress ");
            tableViewLabel.setText("Select students and click Extract Code ");
            stepPane.getChildren().remove(3);
            stepPane.add(extractCodeButton, 1, 1);
            
            fileNameColumn.setText("Student Work Directories");
            
            if(vb1.getChildren().size() != 3){
                vb1.getChildren().add(checkPane);
            }
                        
//            TableSetting Display files in directory: work/assignment/projects/NetID
//            Extract Code from selected files to directory: work/assignment/code/NetID (one directory for each student)
        }
        else if(i == 5){
            homeButton.setDisable(false);
            previousButton.setDisable(false);
            nextButton.setDisable(true);
//            codeCheckButton.setDisable(false);
//            viewResultButton.setDisable(false);
            
            stepLabel.setText("Step 5: Code Check");
            progressLabel.setText("Check Progress ");
            tableViewLabel.setText("Select students and click Code Check ");
            stepPane.getChildren().remove(3);
            stepPane.add(hb3, 1, 1);
            
            fileNameColumn.setText("Student Work ");
            
            if(vb1.getChildren().size() == 3){
                vb1.getChildren().remove(2);
            }

//            TableSetting Display files in directory: work/assignment/code/NetID
//            Code Check displays URL that contains a visual description of the Code Check results
        }
        
    }
    
    public int getStep(){ return i;}
    
    public TableView<Setter> getTable(){
        return table;
    }
    
}
