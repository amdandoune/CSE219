/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.workspace;

import cc.CodeCheckApp;
import cc.data.CodeCheckData;
import cc.data.Setter;
import djf.controller.AppFileController;
import djf.ui.AppMessageDialogSingleton;
import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import properties_manager.PropertiesManager;

/**
 *
 * @author Lenovo
 */
public class CodeCheckController {
    
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    CodeCheckApp app;
    AppFileController fileController;
    String inputFile;
    String outputFile; 
    String inputFileName;
    ReentrantLock progressLock;
//    ArrayList<File> files;
    
    CodeCheckController(CodeCheckApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        fileController = app.getGUI().getFileController();
        progressLock = new ReentrantLock();
    }
    private void markWorkAsEdited() {
        // MARK WORK AS EDITED
        app.getGUI().getFileController().markAsEdited(app.getGUI());
    }
    
    public void handleSeleced(){}
    
    public void handleNew(){
        
        fileController.handleNewRequest();
    }
    
    public void handleLoad(){
        fileController.handleLoadRequest();
    }
    
    public void handleRenameFolder(){
        fileController.handleRename();
    }
    
    public void handleAbout(){
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("Here are information about Code Check");
        alert.setContentText("Author:   Abderrahman Dandoune\n" +"\t\tStony Brook University\n" +"\t\tJune-July 2017\n" +"\t\tVersion 1.0\n" +"Co-Author: Richard McKenna\n" +"\t\tDebugging EnterprisesTM");
        alert.showAndWait();
    }
    
//    public void handleHome(){}
//    public void handlePrevious(){}
//    public void handleNext(){}
    
    public void handleRemove(){
        CodeCheckData data = (CodeCheckData)app.getDataComponent();
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
            
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Remove Dialog");
        alert.setHeaderText("Remove Confirmation Dialog");
        alert.setContentText("Do you want to remove this file?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
        File file = new File (getInputFile());
        
        for (int i=0; i<data.getSetter().size(); i++) {
            
            if(getInputFileName().equals(data.getSetter().get(i).getFileName())){
                System.out.println("Remove File N" + i +" is: "+ data.getSetter().get(i).getFileName());
                data.getSetter().remove(i);
                
                if(getInputFileName().lastIndexOf(".") == -1){
                    if (file != null) {
                        File[] files = file.listFiles();
                        if(files != null)
                        for (File f : files) {
                            if( f != null && f.getName().lastIndexOf(".")== -1){
                                File[] files1 = f.listFiles();
                                if(files1 != null)
                                for (File f1 : files1) {
                                    if( f1 != null && f1.getName().lastIndexOf(".")== -1){
                            
                                }
                                    f1.delete();
                            }
                            f.delete();
                        }
                    }}
                }
//                else{
                    file.delete();
//                }
                workspace.progressDetails.appendText(inputFileName + " has been Removeed succesfully.\n");
                workspace.removeButton.setDisable(true);
                workspace.viewButton.setDisable(true);
                workspace.extractButton.setDisable(true);
                workspace.rename2Button.setDisable(true);
                workspace.unzipButton.setDisable(true);
                workspace.extractCodeButton.setDisable(true);
                workspace.codeCheckButton.setDisable(true);
                workspace.viewResultButton.setDisable(true);
            }
        }
        } else {
            // ... user chose CANCEL or closed the dialog
            workspace.progressDetails.appendText(inputFileName + " has not been Removeed.\n");
        }
    }
    
    public void handleRefresh(){
        System.out.println("REFRESH !!!!");
//        CodeCheckData data = (CodeCheckData)app.getDataComponent();
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
//        workspace.getTable().refresh();
//        displayFileName(getInputFile());
        checkStep(workspace.getStep());

    }
    
    public void handleView(){
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(fileInfo());

        alert.showAndWait();
    }
    
    
    public void handleExtract(){
        inputFile = getInputFile(); //  .work/PROJ_assignment/blackboard
        outputFile = getInputFile().replaceAll("blackboard", "submissions"); // ".\\work\\assignment\\submissions\\HW99_A_through_H"; // 
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
        if(getInputFileName().lastIndexOf(".") != -1){
        String fileExtension = getInputFileName().substring(getInputFileName().lastIndexOf("."), getInputFileName().length());
        if(fileExtension.equals(".zip")){
            extractFiles(inputFile,outputFile);
            workspace.progressDetails.appendText(inputFileName + " has been Extracted succesfully.\n");
        }
        else 
            workspace.progressDetails.appendText(inputFileName + " has not been Extracted .\n");}
        else 
            workspace.progressDetails.appendText(inputFileName + " has not been Extracted .\n");
    }
    
    public void handleRenameFile(){
        
        String fileExtension = getInputFileName().substring(getInputFileName().lastIndexOf("."), getInputFileName().length());
        
        Optional<String> result;
        do{
            TextInputDialog dialog1 = new TextInputDialog();
            dialog1.setTitle("Text Input Dialog");
            dialog1.setHeaderText("Rename of the File");
            dialog1.setContentText("Please enter a new name for the "+ getInputFileName() +" of TYPE : "+ fileExtension);
            // Traditional way to get the response value.
            
            result = dialog1.showAndWait();
            
            if (result.isPresent()){
                System.out.println("Your name: " + result.get());
            }
        }while(fileController.checkFileName(result.get()) == false );
        inputFile = getInputFile();
        outputFile = getInputFile().replaceAll(getInputFileName(), result.get()+fileExtension);

        File oldName = new File(inputFile); // getWorkFolder();
        File newName = new File(outputFile);
        
        app.getGUI().getWindow().setTitle("Code Check - "+result.get());
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
//        workspace.progressDetails.setText("");
        
        if (oldName.renameTo(newName.getAbsoluteFile())) {
        System.out.println("renamed");
        System.out.println(" new: " + newName.getName() +" path: "+ newName.getPath()+" A Path: "+ newName.getAbsolutePath());
        workspace.progressDetails.appendText(inputFileName + " has been renamed to "+ newName.getName() +".\n");
        } else {
         System.out.println("still");
         workspace.progressDetails.appendText(inputFileName + " has failed to be renamed : "+ newName.getName() +".\n");
        }
    }
    
    public void handleUnzip(){
        inputFile = getInputFile();
        outputFile = getInputFile().replaceAll("submissions", "projects");
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
        if(getInputFileName().lastIndexOf(".") != -1){
        String fileExtension = getInputFileName().substring(getInputFileName().lastIndexOf("."), getInputFileName().length());
        if(fileExtension.equals(".zip")){
            unZipIt(inputFile,outputFile.replaceAll(".zip", ""));
            workspace.progressDetails.appendText(inputFileName + " has been unziped.\n");
        }
        else 
            workspace.progressDetails.appendText(inputFileName + " has not been unziped.\n");
        }
        else 
            workspace.progressDetails.appendText(inputFileName + " has not been unziped.\n");
    }
    
    public void handleExtractCode(){
        inputFile = getInputFile(); 
        outputFile = getInputFile().replaceAll("projects", "code");
        
//        String fileExtension = getInputFileName().substring(getInputFileName().lastIndexOf("."), getInputFileName().length());
        File dir = new File(inputFile);
        
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
        workspace.SFT1CheckBox.isSelected();
        
        if (dir != null) {
                File[] files = dir.listFiles();
                if(files != null)
                for (File f : files) {
                    if( f != null ){
                        String fileName0 = f.getName();
                        File[] filess = f.listFiles();
                        if(filess != null)
                        for(File fs: filess){
                        String fileName = fs.getName();
                        if( fs != null ){
                        System.out.println("FILE NAMES IN EC: "+fileName+" INPUT : " +inputFile+" OUTPUT : "+outputFile);
                        if(workspace.SFT1CheckBox.isSelected()){
                            if (fileName.toLowerCase().endsWith(".java")){
                                setExtractCode(fileName0, fileName);
                                workspace.progressDetails.appendText("-"+inputFileName +" ---"+fileName+ " has been Extracted.\n");
                            }
                        }
                        else if(workspace.SFT2CheckBox.isSelected()){
                            if (fileName.toLowerCase().endsWith(".js")){
                                setExtractCode(fileName0, fileName);
                                workspace.progressDetails.appendText("-"+inputFileName +" ---"+fileName+ " has been Extracted.\n");
                            }
                        }
                        else if(workspace.SFT3CheckBox.isSelected()){
                            if (fileName.toLowerCase().endsWith(".c" ) ||
                               fileName.toLowerCase().endsWith(".h") ||
                               fileName.toLowerCase().endsWith(".cpp")){
                                setExtractCode(fileName0, fileName);
                                workspace.progressDetails.appendText("-"+inputFileName +" ---"+fileName+ " has been Extracted.\n");
                            }
                        }
                        else if(workspace.SFT4CheckBox.isSelected()){
                            if (fileName.toLowerCase().endsWith(".cs")){
                                setExtractCode(fileName0, fileName);
                                workspace.progressDetails.appendText("-"+inputFileName +" ---"+fileName+ " has been Extracted.\n");
                            }
                        }
                        else if(workspace.SFT5CheckBox.isSelected()){
                            if (fileName.toLowerCase().endsWith(workspace.SFT5Text.getText())){
                                setExtractCode(fileName0, fileName);
                                workspace.progressDetails.appendText("-"+inputFileName +" ---"+fileName+ " has been Extracted.\n");

                            }
                        }
                        else{
                            workspace.progressDetails.appendText(inputFileName + " did notExtracted.\n");
                        }
                    }}}
                }
        }
    }
    
    public void handleCodeCheck(){
        String q = "Student Plagiarism Check results can be found at  http://www.exampleresults.edu/"+ getInputFileName();
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
        workspace.progressDetails.setText(q);
        workspace.viewResultButton.setDisable(false);
    
    }
    
    public void handleViewResults(){
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Visit Webpage Confirmation Dialog");
        alert.setContentText("Do you want to access: 'http://www.exampleresults.edu/"+ getInputFileName()+"' ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
             try {  
                Desktop.getDesktop().browse(new URI("http://www.exampleresults.edu/"+ getInputFileName()));  
                } catch (IOException exc) {  
                    System.out.println("IOE IN HVR : "+ exc);
                }  catch(URISyntaxException ex){
                    System.out.println("USE IN HVR : "+ ex);
                }
        } else {    
            // ... user chose CANCEL or closed the dialog
        }
    }
    
    public void displayFileName(String f){
        CodeCheckData data = (CodeCheckData)app.getDataComponent();
//        String f; //= fileController.getWorkFolder().getAbsolutePath()+"\\blackboard";
//        if(x == 1){
//            f = fileController.getWorkFolder().getAbsolutePath()+"\\blackboard";
//        }
//        fileController.displayFileName(f, s);
        try{
            data.removeAllSlides();
////        files = new ArrayList<File>();
        File repo1 = new File (f);
//        String path = ".\\work\\"+s;
        File[] fileList1 = repo1.listFiles();
        
        for (int i=0; i<fileList1.length; i++) {
            System.out.println("File N" + i +" is: "+ fileList1[i].getName());
            data.addSlide(fileList1[i].getName(), fileList1[i].getAbsolutePath());
//            if(path.equals(fileList[i].toString())){}
        }
//        
        }
        catch(Exception murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = "Error Message"; // props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = "Error in CheckFileName"; // props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    /**
     * Unzip it
     * @param zipFile input zip file
     * @param output zip file output folder
     */
    public void unZipIt(String zipFile, String outputFolder){

     byte[] buffer = new byte[1024];

     try{

    	//create output directory is not exists
    	File folder = new File(outputFolder);
    	if(!folder.exists()){
    		folder.mkdir();
    	}

    	//get the zip file content
    	ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
    	//get the zipped file list entry
    	ZipEntry ze = zis.getNextEntry();

    	while(ze!=null){

    	   String fileName = ze.getName();
           File newFile = new File(outputFolder + File.separator + fileName);

           System.out.println("file unzip : "+ newFile.getAbsoluteFile());

            //create all non exists folders
            //else you will hit FileNotFoundException for compressed folder
            new File(newFile.getParent()).mkdirs();

            FileOutputStream fos = new FileOutputStream(newFile);

            int len;
            while ((len = zis.read(buffer)) > 0) {
       		fos.write(buffer, 0, len);
            }

            fos.close();
            ze = zis.getNextEntry();
    	}

        zis.closeEntry();
    	zis.close();

    	System.out.println("Done");

    }catch(IOException ex){
//       ex.printStackTrace();
       System.out.println("IOException In UnZipIt : "+ ex);
    }catch(Exception e){
        System.out.println("Exception In UnZipIt : "+ e);
    }
   }
    
    public void handleSelected(){
        //
        System.out.println("handleSelected Done!!!!!!!!!!");
        // GET THE TABLE
        CodeCheckData data = (CodeCheckData)app.getDataComponent();
        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
        TableView sTable = workspace.getTable();
        // IS A Slide SELECTED IN THE TABLE?
        Object selectedItem = sTable.getSelectionModel().getSelectedItem();
        
        int selectedIndex = sTable.getSelectionModel().getSelectedIndex();
        int lastIndex = data.getSetter().size()-1;
        if(selectedIndex >= 0 && selectedIndex <= lastIndex){
            workspace.removeButton.setDisable(false);
            workspace.refreshButton.setDisable(false);
            workspace.viewButton.setDisable(false);
            if(workspace.getStep() == 1){
                workspace.extractButton.setDisable(false);
                workspace.extractButton.setOnMouseClicked(e->{updateProgress(5);}); 
            }
            else if(workspace.getStep() == 2){
                workspace.rename2Button.setDisable(false);
                workspace.extractButton.setOnMouseClicked(e->{updateProgress(2);}); 
            }
            else if(workspace.getStep() == 3){
                workspace.unzipButton.setDisable(false);
                workspace.unzipButton.setOnMouseClicked(e->{updateProgress(5);}); 
            }
            else if(workspace.getStep() == 4){
                workspace.extractCodeButton.setDisable(false);
                workspace.extractCodeButton.setOnMouseClicked(e->{updateProgress(5);}); 
            }
            else if(workspace.getStep() == 5){
                workspace.codeCheckButton.setDisable(false);
                workspace.codeCheckButton.setOnMouseClicked(e->{updateProgress(2);}); 
//                workspace.viewResultButton.setDisable(false);
            }
        }
        else{
            workspace.removeButton.setDisable(true);
            workspace.viewButton.setDisable(true);
            workspace.extractButton.setDisable(true);
            workspace.rename2Button.setDisable(true);
            workspace.unzipButton.setDisable(true);
            workspace.extractCodeButton.setDisable(true);
            workspace.codeCheckButton.setDisable(true);
            workspace.viewResultButton.setDisable(true);
        }
        
        if (selectedItem != null) {
            // GET THE SLIDE
            Setter s = (Setter)selectedItem;
            String name = s.getFileName();
            String file = s.getPath();
            
            ObservableList<Setter> slides = data.getSetter();
            for(Setter sl : slides){
                if(name.equals(sl.getFileName())){
                    System.out.println("SET FILE : "+ sl.getFileName() + " with Path : "+ file);
                    setInputFileName(name);
                    setInputFile(file);
                }
            }
        }
        
    }
    
    public void handleAllSelected(){
        //
        System.out.println("handleAllSelected Done!!!!!!!!!!");
        // GET THE TABLE
//        CodeCheckData data = (CodeCheckData)app.getDataComponent();
//        CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
//        TableView sTable = workspace.getTable();
//        // IS A Slide SELECTED IN THE TABLE?
//        sTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//        sTable.getSelectionModel().setCellSelectionEnabled(true);
//        
//        Object selectedItem = sTable.getSelectionModel().getSelectedItem();

    }
    
    public void setInputFile(String input){
        inputFile = input;
    }
    
    public String getInputFile(){
        return inputFile;
    }
    
    public void setInputFileName(String input){
        inputFileName = input;
    }
    
    public String getInputFileName(){
        return inputFileName;
    }
    
    public void extractFiles(String zipFile, String outputFolder){
        try{
            int c = 0;
            int d = 10000;
        byte[] buf = new byte[1024];
        ZipInputStream zipinputstream = null;
        ZipEntry zipentry;
        zipinputstream = new ZipInputStream(new FileInputStream(zipFile));
        zipentry = zipinputstream.getNextEntry();
        while (zipentry != null) {
            String entryName = zipentry.getName();
            FileOutputStream fileoutputstream;
            File newFile = new File(entryName);
            String directory = newFile.getParent();
            
            if (directory == null) {
                if (newFile.isDirectory())
                    break;
            }
            fileoutputstream = new FileOutputStream(outputFolder + entryName);
            int n;
            while ((n = zipinputstream.read(buf, 0, 1024)) > -1){
                fileoutputstream.write(buf, 0, n);
            }
            fileoutputstream.close();
            zipinputstream.closeEntry();
            zipentry = zipinputstream.getNextEntry();
        }
        zipinputstream.close();
        }catch(RuntimeException r){
            System.out.println("RuntimeException In ExtractFile : "+ r);
        }catch(Exception e){
            System.out.println("Exception In ExtractFile : "+ e);
        }
    }
    
    public void checkStep(int i){
        if(i == 1){
                displayFileName(fileController.getWorkFolder().getAbsolutePath()+"\\blackboard");
            }
            else if(i == 2 || i == 3){
                displayFileName(fileController.getWorkFolder().getAbsolutePath()+"\\submissions");
            }
            else if(i == 4){
                displayFileName(fileController.getWorkFolder().getAbsolutePath()+"\\projects");
            }
            else if(i == 5){
                displayFileName(fileController.getWorkFolder().getAbsolutePath()+"\\code");
            }
    }
    
    public void extractCodeFiles(String inputFolder, String outputFolder){
        try {
            File file = new File(inputFolder);
            File dest = new File(outputFolder); //any location
            Files.copy(file.toPath(), dest.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
        } catch (IOException ex) {
            System.out.println("IOException in ECF"+ex);
        }
    }
    
    public void setExtractCode(String fileName0, String fileName){
        System.out.println("FILE INpUt: "+inputFile.replaceAll(inputFileName, ""));
        System.out.println("FILE oUtpUt: "+outputFile.replaceAll(inputFileName, ""));
        
        extractCodeFiles(inputFile.replaceAll("\\"+inputFileName, ""),outputFile.replaceAll("\\"+inputFileName, ""));
        extractCodeFiles(inputFile,outputFile);
        extractCodeFiles(inputFile+ "\\"+ fileName0,outputFile+ "\\"+ fileName0);
        extractCodeFiles(inputFile+ "\\"+ fileName0+ "\\"+ fileName,outputFile+ "\\"+ fileName0+ "\\"+ fileName);
        
    }
    
    public String fileInfo(){
        String s = "";
        File file = new File (getInputFile());
         if(!file.getName().toLowerCase().endsWith(".zip" )){
                s += "-" + getInputFileName() +" \n";
                    if (file != null) {
                        File[] files = file.listFiles();
                        if(files != null)
                        for (File f : files) {
                            if( f != null ){  
                                s += "\t--" + f.getName() +" \n";
                                File[] files1 = f.listFiles();
                                if(files1 != null)
                                for (File f1 : files1) {
                                    if( f1 != null ){  
                                            s += "\t\t---" + f1.getName() +" \n";
                                            File[] files2 = f1.listFiles();
                                if(files2 != null)
                                for (File f2 : files2) {
                                    if( f2 != null ){ 
                                            s += "\t\t\t----" + f2.getName() +" \n";
                                }
                                }}
                            }
                        }
                    }}}
         else{
             try{
                 ZipFile zipFile = new ZipFile(getInputFile());
                  Enumeration zipEntries = zipFile.entries();
                  while (zipEntries.hasMoreElements()) {
                      String x = ((ZipEntry) zipEntries.nextElement()).getName();
//                      System.out.println(" Zip File: "+x);
                      s += "  - " + x +" \n";
                  }
              }catch(Exception e){}
         }
        
        return s;
    }
    
    public void updateProgress(int a){
        
//        workspace.bar.setOnContextMenuRequested(e -> {
                Task<Void> task = new Task<Void>() {
//                    int task = numTasks++;
                    CodeCheckWorkspace workspace = (CodeCheckWorkspace)app.getWorkspaceComponent();
                    double max = 200;
                    double perc;
                    @Override
                    protected Void call() throws Exception {
                        try {
                            progressLock.lock();
                        for (int i = 0; i <= 200; i++) {
                            System.out.println(i);
                            perc = i/max;
                            
                            // THIS WILL BE DONE ASYNCHRONOUSLY VIA MULTITHREADING
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
				    // WHAT'S MISSING HERE?
//                                    indicator.setProgress(perc);
                                    workspace.bar.setProgress(perc);
                                    workspace.barProgress.setText(perc*100+" %");
//                                    processLabel.setText("Task #" + task);
                                }
                            });

                            // SLEEP EACH FRAME
                            Thread.sleep(a);
                        }}
                        finally {
			    // WHAT DO WE NEED TO DO HERE?
                            progressLock.unlock();
                                }
                        return null;
                    }
                    };
                // THIS GETS THE THREAD ROLLING
                Thread thread = new Thread(task);
                thread.start();            
//        }); 
    }

}
