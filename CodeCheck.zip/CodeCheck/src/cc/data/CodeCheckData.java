/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.data;

import cc.CodeCheckApp;
import djf.components.AppDataComponent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Lenovo
 */
public class CodeCheckData implements AppDataComponent {

     // WE'LL NEED ACCESS TO THE APP TO NOTIFY THE GUI WHEN DATA CHANGES
    CodeCheckApp app;

    // NOTE THAT THIS DATA STRUCTURE WILL DIRECTLY STORE THE
    // DATA IN THE ROWS OF THE TABLE VIEW
    ObservableList<Setter> files;
    String folderName;
    
    /**
     * This constructor will setup the required data structures for use.
     * 
     * @param initApp The application this data manager belongs to. 
     */
    public CodeCheckData(CodeCheckApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        
        // MAKE THE SLIDES MODEL
        files = FXCollections.observableArrayList();
        folderName = "";
    }
    
    // ACCESSOR METHOD
    public ObservableList<Setter> getSetter() {
        return files;
    }
    
    public void setFolderName(String t){
        folderName = t;
    }
    
    public String getFolderName(){
        return folderName;
    }
    
    @Override
    public void resetData() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
     // FOR ADDING A SLIDE WHEN THERE ISN'T A CUSTOM SIZE
    public void addSlide(String fileName, String path) {
        Setter fileToAdd = new Setter(fileName, path);
        files.add(fileToAdd);
    }

    // FOR ADDING A SLIDE WITH A CUSTOM SIZE
   public void addSlide(String fileName, String path, String fileType) {
        Setter fileToAdd = new Setter(fileName, path);
        fileToAdd.setFileNameType(fileType);
        files.add(fileToAdd);
    }
   
   public void removeAllSlides(){
       files.remove(0, files.size());
   }
}
