/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cc.data;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Lenovo
 */
public class Setter {
    private StringProperty fileNameProperty;
    private StringProperty pathProperty;
    private StringProperty fileNameTypeProperty;
    
//    private StringProperty x;
    private StringProperty blackboardFolderName;
    private StringProperty submissionFolderName;
    private StringProperty projectsFolderName;
    private StringProperty codeFolderName;
    
    public Setter(String initFileName, String initPath) {
        fileNameProperty = new SimpleStringProperty(initFileName);
        pathProperty = new SimpleStringProperty(initPath);
        fileNameTypeProperty = new SimpleStringProperty("");
    }
    
    public StringProperty getFileNameProperty() {
        return fileNameProperty;
    }
    public String getFileName() {
        return fileNameProperty.getValue();
    }
    public void setFileName(String initFileName) {
        fileNameProperty.setValue(initFileName);
    }
    
    
    public StringProperty getPathProperty() {
        return pathProperty;
    }
    public String getPath() {
        return pathProperty.getValue();
    }
    public void setPath(String initPath) {
        pathProperty.setValue(initPath);
    }
    
    
    public StringProperty getFileNameTypeProperty() {
        return fileNameTypeProperty;
    }
    public String getFileNameType() {
        return fileNameTypeProperty.getValue();
    }
    public void setFileNameType(String initFileNameType) {
        fileNameTypeProperty.setValue(initFileNameType);
    }
}
