package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.ReentrantLock;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser; //
import javafx.stage.Stage;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

import jtps.jTPS;
import jtps.jTPS_Transaction;
import sc.jtps.*;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @co-author Abderrahman Dandoune
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;
    ////
    static jTPS jTPS = new jTPS();
    ////
    int currentIndex;
    int time;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    private void markWorkAsEdited() {
        // MARK WORK AS EDITED
        app.getGUI().getFileController().markAsEdited(app.getGUI());
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
            int startIndex = data.getSlides().size();
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    if( f != null  && checkDuplicates(f) ){
                        String fileName = f.getName();
                        if (fileName.toLowerCase().endsWith(".png") ||
                               fileName.toLowerCase().endsWith(".jpg") ||
                               fileName.toLowerCase().endsWith(".gif")) {
                            String path = f.getPath();
//                            String caption = "";
                            Image slideShowImage = loadImage(path);
//                            int originalWidth = (int)slideShowImage.getWidth();
//                            int originalHeight = (int)slideShowImage.getHeight();
//                            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//                            data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                            /////
                            jTPS_Transaction transaction = new JTPSAddAllImages(app, f, slideShowImage, startIndex, dir);
                            jTPS.addTransaction(transaction);
                            /////
                            app.getGUI().getFileToolbar().getChildren().get(5).setDisable(false);
                        }
                    }
                }
            }
//            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
            SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
            TableView sTable = workspace.getSlidesTableView();
            sTable.scrollTo(data.getSlides().size()-1);
            
            markWorkAsEdited();
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    public Image loadImage(String imagePath) throws MalformedURLException { // was private
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
    //////////////////////////////////////
    
    // CONTROLLER METHOD THAT HANDLES ADDING AN IMAGE FROM A DIRECTORY
    public void handleAddImageFromDirectory(){
        try {
            // ASK THE USER TO SELECT A FILE
            FileChooser fileChooser = new FileChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            fileChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File f = fileChooser.showOpenDialog(app.getGUI().getWindow());
            if ( f != null && checkDuplicates(f) ) {
                String fileName = f.getName();                
                if (fileName.toLowerCase().endsWith(".png") ||     fileName.toLowerCase().endsWith(".jpg") ||fileName.toLowerCase().endsWith(".gif")) { 
//                    String path = f.getPath(); 
//                    String caption = ""; 
//                    System.out.println("THE PATH1: "+f.getPath());
                    Image slideShowImage = loadImage(f.getPath()); 
//                    int originalWidth = (int)slideShowImage.getWidth(); 
//                    int originalHeight = (int)slideShowImage.getHeight(); 
                    /////
                    jTPS_Transaction transaction = new JTPSAddImage(app, f, slideShowImage);
                    jTPS.addTransaction(transaction);
                    /////
                    
                    SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//                    data.addSlide(fileName, path, caption, originalWidth, originalHeight);
//                    System.out.println("THE PATH2: "+data.getSlides().get(data.getSlides().size()-1).getPath());
                    SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
                    TableView sTable = workspace.getSlidesTableView();
                    sTable.getSelectionModel().select(data.getSlides().size()-1);
                    sTable.scrollTo(data.getSlides().size()-1);
                    handleSelected();
                    app.getGUI().getFileToolbar().getChildren().get(5).setDisable(false);
                    
                    markWorkAsEdited();
                }
            }
            
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public void afterRemove(){
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView sTable = workspace.getSlidesTableView();
        sTable.getSelectionModel().select(null);
        workspace.setFileNameTextField("");
        workspace.setPathTextField("");
        workspace.setCaptionTextField("");
        workspace.originalHeightTextField.setText(null);
        workspace.originalWidthTextField.setText(null);
        workspace.setCurrentHeightSlider(0);
        workspace.setCurrentWidthSlider(0);
        workspace.setPositionXSlider(0);
        workspace.setPositionYSlider(0);
        workspace.captionTextField.setDisable(true);
        workspace.currentWidthSlider.setDisable(true);
        workspace.currentHeightSlider.setDisable(true);
        workspace.positionXSlider.setDisable(true);
        workspace.positionYSlider.setDisable(true);
        workspace.removeImageButton.setDisable(true);
        workspace.updateButton.setDisable(true);
        workspace.editPane.getChildren().remove(workspace.slideImage);
    }
    
    // CONTROLLER METHOD THAT HANDLES REMOVING AN IMAGE 
    public void handleRemoveImage(){
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView sTable = workspace.getSlidesTableView();
        
        // IS A Slide SELECTED IN THE TABLE?
        Object selectedItem = sTable.getSelectionModel().getSelectedItem();
        Slide s = (Slide)selectedItem;
        /////
        jTPS_Transaction transaction = new JTPSRemoveImage(app, s, getIndex(s));
        jTPS.addTransaction(transaction);
        /////
//        afterRemove();
//        data.getSlides().remove(s);
        
        if(data.getSlides().size() == 0){
            app.getGUI().getFileToolbar().getChildren().get(5).setDisable(true);
        }
        markWorkAsEdited();
        
    }
    
    // CONTROLLER METHOD THAT HANDLES UPDATING AN IMAGE 
    public void handleUpdate(){
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView sTable = workspace.getSlidesTableView();
        
        // IS A Slide SELECTED IN THE TABLE?
        Object selectedItem = sTable.getSelectionModel().getSelectedItem();
        Slide s = (Slide)selectedItem;
//        int i = getIndex(s);
        s.setCaption(workspace.getCaptionTextField());
        s.setCurrentHeight(workspace.getCurrentHeightSlider());
        s.setCurrentWidth(workspace.getCurrentWidthSlider());
        s.setPositionX(workspace.getPositionXSlider());
        s.setPositionY(workspace.getPositionYSlider());
        sTable.refresh();
       
        handleSelected();
        /////
//        jTPS_Transaction transaction = new JTPSUpdate(app);
//        jTPS.addTransaction(transaction);
        /////
        handleSelected();
        workspace.updateButton.setDisable(true);
        markWorkAsEdited();
    }
    
    public int getIndex(Slide s){
        int i=0;
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        ObservableList<Slide> slides = data.getSlides();
        for(Slide sl : slides){
            if(s.getFileName().equals(sl.getFileName()) && s.getPath().equals(sl.getPath()) )
                return i;
            else 
                i++;
        }
        return i;
    }
    
    //  CHECK FOR DUPICATES
    public boolean checkDuplicates(File f){
        boolean b = true;
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        ObservableList<Slide> slides = data.getSlides();
        for(Slide s : slides){
            if(f.getName().equals(s.getFileName()) && f.getPath().equals(s.getPath())){
                b = false;
            }
        } 
        return b;
    }
    
    public void handleSlideShowTitle(){
//        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
//        data.setSlideShowTitle(workspace.getSlideShowTitle());
//        s.setCaption(workspace.getCaptionTextField());
        /////
        jTPS_Transaction transaction = new JTPSSlideShowTitle(app);
        jTPS.addTransaction(transaction);
        /////
        markWorkAsEdited();
    }
    
    // MOVE SLIDE UP
    public void moveUp(){
//        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
//        TableView sTable = workspace.getSlidesTableView();
//        
//        // IS A Slide SELECTED IN THE TABLE?
//        int selectedIndex = sTable.getSelectionModel().getSelectedIndex();
//        ObservableList<Slide> slides = data.getSlides();
//        Slide removeItem = slides.remove(selectedIndex);
//        int newIndex = selectedIndex - 1;
//        slides.add(newIndex, removeItem);
//        sTable.getSelectionModel().select(newIndex);
//        
//        sTable.refresh();
       
//        handleSelected();
        /////
        jTPS_Transaction transaction = new JTPSMoveUp(app);
        jTPS.addTransaction(transaction);
        /////
        handleSelected();
        markWorkAsEdited();
    }
    
    // MOVE SLIDE UDOWN
    public void moveDown(){
//        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
//        TableView sTable = workspace.getSlidesTableView();
//        
//        // IS A Slide SELECTED IN THE TABLE?
//        int selectedIndex = sTable.getSelectionModel().getSelectedIndex();
//        ObservableList<Slide> slides = data.getSlides();
//        Slide removeItem = slides.remove(selectedIndex);
//        int newIndex = selectedIndex + 1;
//        slides.add(newIndex, removeItem);
//        sTable.getSelectionModel().select(newIndex);
//        
//        sTable.refresh();
        
        /////
        jTPS_Transaction transaction = new JTPSMoveDown(app);
        jTPS.addTransaction(transaction);
        /////
        handleSelected();
        markWorkAsEdited();
    }
    
    public void undo(){
        jTPS.undoTransaction();
        markWorkAsEdited();
    }
    
    public void redo(){
        jTPS.doTransaction();
        markWorkAsEdited();
    }
    
    public void slideThumbnail(Slide s){
//        File f = new File(s.getPath());
//        f.getPath() = (File)s.getPath();
//        String path = f.getPath();
//        Image image =  loadImage(path);     //new Image("file:"+s.getPath()+s.getFileName());
//        iv.setImage(image);
//
//        FadeTransition ft = new FadeTransition();
//        ft.setNode(iv);
//        ft.setDuration(new Duration(2000));
//        ft.setFromValue(1.0);
//        ft.setToValue(0.0);
//        ft.setCycleCount(6);
//        ft.setAutoReverse(true);
    } 
    
    public void handleSlideShowDisplay(){
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
//        TableView sTable = workspace.getSlidesTableView();
        VBox vb = new VBox();  // ||
        HBox hb = new HBox();  // =
        Button startButton = new Button("Start");
        Button pauseButton = new Button("Pause");
        Button prevButton = new Button("Prev");
        Button nextButton = new Button("Next");
        Label captionLabel = new Label();
        pauseButton.setDisable(true);
        startButton.setDisable(false);
        time = 0;
        ReentrantLock lock = new ReentrantLock();
        
        hb.getChildren().addAll(prevButton, startButton, pauseButton, nextButton);
        hb.setAlignment(Pos.CENTER);
        vb.setAlignment(Pos.CENTER);
        vb.getChildren().addAll(hb, captionLabel);
        HashMap<String, Image> images = new HashMap();
        HashMap<String, String> captions = new HashMap();
        ArrayList<String> names = new ArrayList();
        currentIndex = 0;
        ImageView image = new ImageView();
        
        for(int i=0 ; i<data.getSlides().size(); i++){
            String text = data.getSlides().get(i).getFileName();
            try {
		Image studentImage = loadImage(data.getSlides().get(i).getPath());
		images.put(text, studentImage);
                captions.put(text, data.getSlides().get(i).getCaption());
		names.add(text);
	    } catch (Exception e) {
		System.out.println("ERROR: " + text);
	    }
        }
        
        String startingStudent = names.get(currentIndex);
//        Image startingImage = images.get(startingStudent);
        String startingCaption = captions.get(startingStudent);
        captionLabel.setText("Caption: \""+startingCaption+"\"");
        image.setImage(images.get(startingStudent));
        Slide sd = data.getSlides().get(currentIndex);
        image.setFitHeight(sd.getCurrentHeight());
        image.setFitWidth(sd.getCurrentWidth());
        image.setLayoutX(sd.getPositionX());
        image.setLayoutY(sd.getPositionY());
        
        Stage stage2 = new Stage();
        BorderPane pane = new BorderPane();
        Pane pane1 = new Pane();
        pane1.getChildren().add(image);
//        vb.setAlignment(Pos.BOTTOM_CENTER);
//        pane.setLeft(image);
        pane.setCenter(pane1);
        pane.setBottom(vb);
        Scene scene = new Scene(pane, 800, 800);
        stage2.setTitle("Title: "+ data.getSlideShowTitle());
        stage2.setScene(scene);
        
        
        // PROVIDE A RESPONSE TO BUTTON CLICKS
	EventHandler buttonsHandler = new EventHandler<ActionEvent>() {
	    @Override
	    public void handle(ActionEvent event) {
		Task<Void> task = new Task<Void>() {
		    @Override
		    protected Void call() throws Exception {
			int maxCount = 1; // PREV AND NEXT BUTTONS INC BY 1
//			if (event.getSource() == pickButton) 
			    maxCount = data.getSlides().size(); // RANDOM BUTTON FLIPS THROUGH 15 STUDENTS
                            boolean play = true;
//			while(play) {
			    if (event.getSource() == prevButton)
			    {
				currentIndex -= 1;
				if (currentIndex < 0)
				    currentIndex = data.getSlides().size() - 1;
			    }
			    else if (event.getSource() == nextButton)
			    {
				currentIndex += 1;
                                if (currentIndex >= data.getSlides().size())
				    currentIndex = 0;
			    }
                            else if (event.getSource() == startButton)
			    {
				time = 2000;
                                
//                                lock.unlock();
                                pauseButton.setDisable(false);
                                startButton.setDisable(true);
			    }
                            else if (event.getSource() == pauseButton)
			    {
				time = 2000000;
//                                lock.lock();
                                pauseButton.setDisable(true);
                                startButton.setDisable(false);
			    }

			    // THIS WILL BE DONE ASYNCHRONOUSLY VIA MULTITHREADING
			    Platform.runLater(new Runnable() {
				@Override
				public void run() {
                                    String student = names.get(currentIndex);
                                    String startingCaption = captions.get(student);
                                    captionLabel.setText("Caption: \""+startingCaption+"\"");
                                    image.setImage(images.get(student));
                                    Slide sd = data.getSlides().get(currentIndex);
                                    image.setFitHeight(sd.getCurrentHeight());
                                    image.setFitWidth(sd.getCurrentWidth());
                                    image.setLayoutX(sd.getPositionX());
                                    image.setLayoutY(sd.getPositionY());
				}
			    });

			    // SLEEP EACH FRAME
			    try {
				Thread.sleep(time);
			    } catch (InterruptedException ie) {
				ie.printStackTrace();
			    }
//			}
			return null;
		    }
		};
		// THIS GETS THE THREAD ROLLING
		Thread thread = new Thread(task);
//                startButton.setOnAction(e->{
//                    if(time == 0)
                    thread.start();
//                    pauseButton.setDisable(false);
//                    startButton.setDisable(true);
//                }); 
//                pauseButton.setOnAction(e->{
//                    if(time == 1)
//                        thread.stop();
//                    pauseButton.setDisable(true);
//                    startButton.setDisable(false);
//                });
		
	    }
	};

	// REGISTER THE LISTENER WITH ALL 3 BUTTONS
	prevButton.setOnAction(buttonsHandler);
	startButton.setOnAction(buttonsHandler);
        pauseButton.setOnAction(buttonsHandler);
	nextButton.setOnAction(buttonsHandler);

        
        
        stage2.show(); //AndWait();
        
//        prevButton.setOnAction(e->{
//            currentIndex -= 1;
//            if(currentIndex < 0){
//                currentIndex = data.getSlides().size()-1;
//            }
//        });
//        
//        nextButton.setOnAction(e->{
//            currentIndex += 1;
//            if(currentIndex >= data.getSlides().size()){
//                currentIndex = 0;
//            }
//        });
//        startButton.setOnAction(e->{
//        
//            pauseButton.setDisable(false);
//            startButton.setDisable(true);
//        });
//        pauseButton.setOnAction(e->{
//        
//            pauseButton.setDisable(true);
//            startButton.setDisable(false);
//        });
    }
    
//    public Slide getSlidePic(){
//        
//        return s;
//    }
    public void handlePause(){}
    public void handlePlay(){}
    public void handleNext(){
//        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//        currentIndex += 1;
//            if(currentIndex >= data.getSlides().size()){
//                currentIndex = 0;
//            }
    }
    public void handlePrev(){
//        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
//        currentIndex -= 1;
//            if(currentIndex < 0){
//                currentIndex = data.getSlides().size()-1;
//            }
    }
    
    public void handleSelected(){
        // GET THE TABLE
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView sTable = workspace.getSlidesTableView();
        workspace.editPane.getChildren().remove(workspace.slideImage);
        // IS A Slide SELECTED IN THE TABLE?
        Object selectedItem = sTable.getSelectionModel().getSelectedItem();
        
        int selectedIndex = sTable.getSelectionModel().getSelectedIndex();
        int lastIndex = data.getSlides().size()-1;
        if(selectedIndex == 0){
            workspace.moveUpButton.setDisable(true);
        }
        else if(selectedIndex != 0){
            workspace.moveUpButton.setDisable(false);
        }
        
        if(selectedIndex == lastIndex){
            workspace.moveDownButton.setDisable(true);
        }
        else if(selectedIndex != lastIndex){
            workspace.moveDownButton.setDisable(false);
        }
        
        
        if (selectedItem != null) {
            // GET THE SLIDE
            Slide s = (Slide)selectedItem;
            slideThumbnail(s);
            String sName = s.getFileName();
//            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
            ObservableList<Slide> slides = data.getSlides();
            for(Slide sl : slides){
                if(sName.equals(sl.getFileName())){
                    
                    System.out.println(s.getPath());
                    
                    workspace.setFileNameTextField(sName);
                    workspace.setPathTextField(s.getPath());
                    workspace.setCaptionTextField(s.getCaption());
                    workspace.setOriginalHeightTextField(s.getOriginalHeight());
                    workspace.setOriginalWidthTextField(s.getOriginalWidth());
                    workspace.setCurrentHeightSlider(s.getCurrentHeight());
                    workspace.setCurrentWidthSlider(s.getCurrentWidth());
                    workspace.setPositionXSlider(s.getPositionX());
                    workspace.setPositionYSlider(s.getPositionY());
                    workspace.captionTextField.setDisable(false);
                    workspace.currentWidthSlider.setDisable(false);
                    workspace.currentHeightSlider.setDisable(false);
                    workspace.positionXSlider.setDisable(false);
                    workspace.positionYSlider.setDisable(false);
                    workspace.removeImageButton.setDisable(false);
                    workspace.updateButton.setDisable(true);
                    workspace.editPane.add(workspace.slideImage, 1, 9);
                    
                    workspace.slideImage.setFitHeight(s.getOriginalHeight());
                    workspace.slideImage.setFitWidth(s.getOriginalWidth());
                    try {
                        Image studentImage = loadImage(data.getSlides().get(getIndex(s)).getPath());
                        workspace.slideImage.setImage(studentImage);
                        
                    } catch (Exception e) {
                        System.out.println("ERROR: ");
                    }
//                    int i = getIndex(s);
//                    Image studentImage = loadImage(data.getSlides().get(i).getPath());
////                    String path = loadImage(s.getPath());
//                    workspace.slideImage.setImage(studentImage);
                    
                    workspace.captionTextField.setOnKeyReleased(e->{
                        if(!s.getCaption().equals(workspace.getCaptionTextField()))
                            workspace.updateButton.setDisable(false);
                        else if (s.getCaption().equals(workspace.getCaptionTextField()) && s.getCurrentHeight().equals(workspace.getCurrentHeightSlider()) 
                                && s.getCurrentWidth().equals(workspace.getCurrentWidthSlider()) && s.getPositionX().equals(workspace.getPositionXSlider()) 
                                && s.getPositionY().equals(workspace.getPositionYSlider())
                                )
                                workspace.updateButton.setDisable(true);
                    });
                    
                    workspace.currentWidthSlider.setOnMouseReleased(e->{ 
                        if(!s.getCurrentWidth().equals(workspace.getCurrentWidthSlider()))
                            workspace.updateButton.setDisable(false);
                        else if (s.getCaption().equals(workspace.getCaptionTextField()) && s.getCurrentHeight().equals(workspace.getCurrentHeightSlider()) 
                                && s.getCurrentWidth().equals(workspace.getCurrentWidthSlider()) && s.getPositionX().equals(workspace.getPositionXSlider()) 
                                && s.getPositionY().equals(workspace.getPositionYSlider())
                                )
                                workspace.updateButton.setDisable(true);
                        
                    });
                    workspace.currentHeightSlider.setOnMouseReleased(e->{
                        if(!s.getCurrentHeight().equals(workspace.getCurrentHeightSlider()))
                            workspace.updateButton.setDisable(false);
                        else if (s.getCaption().equals(workspace.getCaptionTextField()) && s.getCurrentHeight().equals(workspace.getCurrentHeightSlider()) 
                                && s.getCurrentWidth().equals(workspace.getCurrentWidthSlider()) && s.getPositionX().equals(workspace.getPositionXSlider()) 
                                && s.getPositionY().equals(workspace.getPositionYSlider())
                                )
                                workspace.updateButton.setDisable(true);
                        
                    });
                    workspace.positionXSlider.setOnMouseReleased(e->{
                        if(!s.getPositionX().equals(workspace.getPositionXSlider()))
                            workspace.updateButton.setDisable(false);
                        else if (s.getCaption().equals(workspace.getCaptionTextField()) && s.getCurrentHeight().equals(workspace.getCurrentHeightSlider()) 
                                && s.getCurrentWidth().equals(workspace.getCurrentWidthSlider()) && s.getPositionX().equals(workspace.getPositionXSlider()) 
                                && s.getPositionY().equals(workspace.getPositionYSlider())
                                )
                                workspace.updateButton.setDisable(true);
                        
                    });
                    workspace.positionYSlider.setOnMouseReleased(e->{
                        if(!s.getPositionY().equals(workspace.getPositionYSlider()))
                            workspace.updateButton.setDisable(false);
                        else if (s.getCaption().equals(workspace.getCaptionTextField()) && s.getCurrentHeight().equals(workspace.getCurrentHeightSlider()) 
                                && s.getCurrentWidth().equals(workspace.getCurrentWidthSlider()) && s.getPositionX().equals(workspace.getPositionXSlider()) 
                                && s.getPositionY().equals(workspace.getPositionYSlider())
                                )
                                workspace.updateButton.setDisable(true);
                        
                    });
                    
                }
            }
        }
    }
    
    /////////////////////////////////////////
}