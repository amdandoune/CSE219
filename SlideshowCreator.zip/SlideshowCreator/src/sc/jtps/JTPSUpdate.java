/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.jtps;

import javafx.scene.control.TableView;
import jtps.jTPS_Transaction;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorWorkspace;

/**
 *
 * @author Lenovo
 */
public class JTPSUpdate implements jTPS_Transaction {
    SlideshowCreatorApp app;
    SlideshowCreatorData data;
    SlideshowCreatorWorkspace workspace;
    TableView sTable;
    Object selectedItem;
    Slide s;
    boolean undoCount;
    String captionO;
    int currentHO;
    int currentWO;
    int posXO;
    int posYO;
    String captionN;
    int currentHN;
    int currentWN;
    int posXN;
    int posYN;
    
    public JTPSUpdate(SlideshowCreatorApp intapp) {
        app = intapp;
        data = (SlideshowCreatorData)app.getDataComponent();
        workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        sTable = workspace.getSlidesTableView();
        undoCount = false;
        
        // IS A Slide SELECTED IN THE TABLE?
        selectedItem = sTable.getSelectionModel().getSelectedItem();
        s = (Slide)selectedItem;
        captionN = "";
        currentHN = 200;
        currentWN = 200;
        posXN = 0;
        posYN = 0;
        captionO = "";
        currentHO = 200;
        currentWO = 200;
        posXO = 0;
        posYO = 0;
        
    }
    
    @Override
    public void doTransaction() {
        // bring back the updates

            
//        if(undoCount){
            captionN = workspace.getCaptionTextField();
            currentHN = workspace.getCurrentHeightSlider();
            currentWN = workspace.getCurrentWidthSlider();
            posXN = workspace.getPositionXSlider();
            posYN = workspace.getPositionYSlider();
//        }
        
        s.setCaption(captionN);
        s.setCurrentHeight(currentHN);
        s.setCurrentWidth(currentWN);
        s.setPositionX(posXN);
        s.setPositionY(posYN);
        sTable.refresh();
    }

    @Override
    public void undoTransaction() {
        // remove the updates
        
        
//        
//        captionN = workspace.getCaptionTextField();
//        currentHN = workspace.getCurrentHeightSlider();
//        currentWN = workspace.getCurrentWidthSlider();
//        posXN = workspace.getPositionXSlider();
//        posYN = workspace.getPositionYSlider();
        
        s.setCaption(captionO);
        s.setCurrentHeight(currentHO);
        s.setCurrentWidth(currentWO);
        s.setPositionX(posXO);
        s.setPositionY(posYO);
        
        captionO = workspace.getCaptionTextField();
        currentHO = workspace.getCurrentHeightSlider();
        currentWO = workspace.getCurrentWidthSlider();
        posXO = workspace.getPositionXSlider();
        posYO = workspace.getPositionYSlider();
        
        sTable.refresh();
        undoCount = true;
    }
    
}
