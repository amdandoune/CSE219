/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.jtps;

import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import jtps.jTPS_Transaction;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorWorkspace;

/**
 *
 * @author Lenovo
 */
public class JTPSMoveDown implements jTPS_Transaction {
    SlideshowCreatorApp app;
    SlideshowCreatorData data;
    SlideshowCreatorWorkspace workspace;
    TableView sTable;
    int selectedIndex;
    ObservableList<Slide> slides;
    Slide removeItem;
    
    public JTPSMoveDown(SlideshowCreatorApp intapp) {
        app = intapp;
        data = (SlideshowCreatorData)app.getDataComponent();
        workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        sTable = workspace.getSlidesTableView();
        
        // IS A Slide SELECTED IN THE TABLE?
//        selectedIndex = sTable.getSelectionModel().getSelectedIndex();
//        slides = data.getSlides();
//        removeItem = slides.remove(selectedIndex);
    }
    
    @Override
    public void doTransaction() {
        // move down
        selectedIndex = sTable.getSelectionModel().getSelectedIndex();
        slides = data.getSlides();
        removeItem = slides.remove(selectedIndex);
        int newIndex = selectedIndex + 1;
        slides.add(newIndex, removeItem);
        sTable.getSelectionModel().select(newIndex);
        sTable.refresh();
    }

    @Override
    public void undoTransaction() {
        // move up
        selectedIndex = sTable.getSelectionModel().getSelectedIndex();
        slides = data.getSlides();
        removeItem = slides.remove(selectedIndex);
        int newIndex = selectedIndex - 1;
        slides.add(newIndex, removeItem);
        sTable.getSelectionModel().select(newIndex);
        sTable.refresh();
    }
    
}
