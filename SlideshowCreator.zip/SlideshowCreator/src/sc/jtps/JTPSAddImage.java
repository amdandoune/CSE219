/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.jtps;

import java.io.File;
import javafx.scene.image.Image;
import jtps.jTPS_Transaction;
import sc.SlideshowCreatorApp;
import sc.data.SlideshowCreatorData;

/**
 *
 * @author Lenovo
 */
public class JTPSAddImage implements jTPS_Transaction {
    
    SlideshowCreatorApp app;
    SlideshowCreatorData data;
    String fileName;
    String path;
    String caption;
    int originalHeight;
    int originalWidth;
    
    
    public JTPSAddImage(SlideshowCreatorApp intapp,File f, Image slideShowImage) {
        app = intapp;
        fileName = f.getName();
        path = f.getPath();
        caption = "";
        originalWidth = (int)slideShowImage.getWidth();
        originalHeight = (int)slideShowImage.getHeight();
        
        data = (SlideshowCreatorData)app.getDataComponent();
    }
    
    @Override
    public void doTransaction() {
        // add the removed image by undo
        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
    }

    @Override
    public void undoTransaction() {
        // delete most recent added image
        data.getSlides().remove(data.getSlides().size()-1);
    }
    
}
