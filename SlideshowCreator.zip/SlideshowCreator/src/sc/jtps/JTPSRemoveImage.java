/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.jtps;

import javafx.scene.control.TableView;
import jtps.jTPS_Transaction;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorController;
import sc.workspace.SlideshowCreatorWorkspace;

/**
 *
 * @author Lenovo
 */
public class JTPSRemoveImage implements jTPS_Transaction {
    SlideshowCreatorApp app;
    SlideshowCreatorData data;
    String fileName;
    String path;
    String caption;
    int originalHeight;
    int originalWidth;
    int currentHeight;
    int currentWidth;
    int posX;
    int posY;
    Slide sl;
    int deletedIndex;
    SlideshowCreatorController controller;
    
    public JTPSRemoveImage(SlideshowCreatorApp intapp, Slide s, int index) {
        sl=s;
        deletedIndex=index;
        app = intapp;
        data = (SlideshowCreatorData)app.getDataComponent();
        controller = new SlideshowCreatorController(app);
    }
    
    @Override
    public void doTransaction() {
        // remove
        data.getSlides().remove(sl);
        controller.afterRemove();
    }

    @Override
    public void undoTransaction() {
        // add to the exact index
        data.getSlides().add(deletedIndex, sl);
    }
    
}
