/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.jtps;

import java.io.File;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import jtps.jTPS_Transaction;
import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorController;

/**
 *
 * @author Lenovo
 */
public class JTPSAddAllImages implements jTPS_Transaction {
    
    SlideshowCreatorApp app;
    SlideshowCreatorData data;
    String fileName;
    String path;
    String caption;
    int originalHeight;
    int originalWidth;
    int startIndex;
    int lastIndex;
    ObservableList<Slide> slides;
    File dirs;
    SlideshowCreatorController controller;
//    Image slideShowImage;
    
    public JTPSAddAllImages(SlideshowCreatorApp intapp,File f, Image slideShowImage, int index, File dir) {
        app = intapp;
        fileName = f.getName();
        path = f.getPath();
        caption = "";
        originalWidth = (int)slideShowImage.getWidth();
        originalHeight = (int)slideShowImage.getHeight();
        
        slides = FXCollections.observableArrayList();
        startIndex = index;
        data = (SlideshowCreatorData)app.getDataComponent();
        lastIndex = data.getSlides().size();
        dirs = dir;
        controller = new SlideshowCreatorController(app);
    }
    
    @Override
    public void doTransaction() {
        //readd the most resent remove group of images
//        File[] files = dirs.listFiles();
//        for (File f : files) {
//            if( f != null  && controller.checkDuplicates(f) ){
//                fileName = f.getName();
//                if (fileName.toLowerCase().endsWith(".png") ||
//                        fileName.toLowerCase().endsWith(".jpg") ||
//                        fileName.toLowerCase().endsWith(".gif")) {
//                    path = f.getPath();
//                            String caption = "";
//                    slideShowImage = controller.loadImage(f.getPath());
                    if(slides.size() == 0) {
                        data.addSlide(fileName, path, caption, originalWidth, originalHeight);
                    }
                    else{
                        for(int i = 0 ; i<slides.size() ; i++){
                            data.addSlide(slides.get(i).getFileName(), slides.get(i).getPath(), slides.get(i).getCaption(), slides.get(i).getOriginalWidth(), slides.get(i).getOriginalHeight());
                        }
                    }
//                }
//            }
//        }
    }

    @Override
    public void undoTransaction() {
        // remove the latest group added
        for(int i=0; i<(lastIndex-startIndex+1); i++){
            slides.add(i, data.getSlides().get(startIndex+i));
            
        }
            data.getSlides().remove(startIndex, lastIndex+1);

    }
    
}
