/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sc.jtps;

import jtps.jTPS_Transaction;
import sc.SlideshowCreatorApp;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorWorkspace;

/**
 *
 * @author Lenovo
 */
public class JTPSSlideShowTitle implements jTPS_Transaction {
    SlideshowCreatorApp app;
    SlideshowCreatorData data;
    SlideshowCreatorWorkspace workspace;
    String oldTitle;
    String newTitle;
    boolean undoCount;
    
    public JTPSSlideShowTitle(SlideshowCreatorApp intapp) {
        app = intapp;
        data = (SlideshowCreatorData)app.getDataComponent();
        workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        oldTitle = "";
        newTitle = "";
        undoCount = false;
    }
    
    @Override
    public void doTransaction() {
        // undo the undo
        oldTitle = workspace.getSlideShowTitle();
        data.setSlideShowTitle(workspace.getSlideShowTitle());
//            workspace.setSlideShowTitle(workspace.getSlideShowTitle());
        if(undoCount){
            data.setSlideShowTitle(newTitle);
            workspace.setSlideShowTitle(newTitle);
        }
    }

    @Override
    public void undoTransaction() {
        // reset to previous step
        newTitle = workspace.getSlideShowTitle();
        data.setSlideShowTitle(oldTitle);
        workspace.setSlideShowTitle(oldTitle);
        undoCount = true;
    }
    
}
