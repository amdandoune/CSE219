package recitation4_javafx;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;

/**
 *
 * @author McKillaGorilla
 */
public class RedBoxManRenderer extends Application {
    Canvas canvas;
    GraphicsContext gc;
    ArrayList<Point2D> imagesRedBoxManLocations;
    ArrayList<Point2D> shapesRedBoxManLocations;
    Image redBoxManImage;
    
    @Override
    public void start(Stage primaryStage) {
	// INIT THE DATA MANAGERS
	imagesRedBoxManLocations = new ArrayList();
	shapesRedBoxManLocations = new ArrayList();
	
	// LOAD THE RED BOX MAN IMAGE
	redBoxManImage = new Image("RedBoxMan.png");
	
	// MAKE THE CANVAS
	canvas = new Canvas();
	canvas.setStyle("-fx-background-color: cyan");
	gc = canvas.getGraphicsContext2D();

	// PUT THE CANVAS IN A CONTAINER
	Group root = new Group();
	root.getChildren().add(canvas);
	
	canvas.setOnMouseClicked(e->{
	    if (e.isShiftDown()) {
		shapesRedBoxManLocations.add(new Point2D(e.getX(), e.getY()));
		render();
	    }
	    else if (e.isControlDown()) {
		imagesRedBoxManLocations.add(new Point2D(e.getX(), e.getY()));
		render();
	    }
	    else {
		clear();
	    }
	});
	
	// PUT THE CONTAINER IN A SCENE
	Scene scene = new Scene(root, 800, 600);
	canvas.setWidth(scene.getWidth());
	canvas.setHeight(scene.getHeight());

	// AND START UP THE WINDOW
	primaryStage.setTitle("Red Box Man Renderer");
	primaryStage.setScene(scene);
	primaryStage.show();
    }
    
    public void clearCanvas() {
	gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }
    
    public void clear() {
	shapesRedBoxManLocations.clear();
	imagesRedBoxManLocations.clear();
	render();
    }
    
    public void render() {
	clearCanvas();
	for (int i = 0; i < shapesRedBoxManLocations.size(); i++) {
	    renderShapeRedBoxMan(shapesRedBoxManLocations.get(i));
	}
	for (int j = 0; j < imagesRedBoxManLocations.size(); j++) {
	    renderImageRedBoxMan(imagesRedBoxManLocations.get(j));
	}
    }
    
    public void renderShapeRedBoxMan(Point2D location) {
	String headColor = "#DD0000";
	String outlineColor = "#000000";
	int headW = 115;
	int headH = 88;
        
        String colorBlack = "#000000";
        String colorYellow = "#FFFF00";
        
        int eyeLeftW = 20;
        int eyeLeftH = 20;
        int eyeBallLW = 5;
        int eyeBallLH = 5;
        int mouthW = 90;
        int mouthH = 10;
        int shoulderW = 80;
        int shoulderH = 20;
        int bellyW = 60;
        int bellyH = 10;
        int footLW = 10;
        int footLH = 10;
    
	// DRAW HIS RED HEAD
        gc.setFill(Paint.valueOf(headColor));
	gc.fillRect(location.getX(), location.getY(), headW, headH);
        gc.setFill(Paint.valueOf(colorYellow));
	gc.fillRect(location.getX()+15, location.getY()+15, eyeLeftW, eyeLeftH);
	gc.fillRect(location.getX()+80, location.getY()+15, eyeLeftW, eyeLeftH);
        gc.setFill(Paint.valueOf(colorBlack));
	gc.fillRect(location.getX()+22, location.getY()+22, eyeBallLW, eyeBallLH);
        gc.fillRect(location.getX()+87, location.getY()+22, eyeBallLW, eyeBallLH);
        gc.fillRect(location.getX()+12, location.getY()+68, mouthW, mouthH);
        gc.fillRect(location.getX()+18, location.getY()+88, shoulderW, shoulderH);
        gc.fillRect(location.getX()+28, location.getY()+108, bellyW, bellyH);
        gc.fillRect(location.getX()+18, location.getY()+118, footLW, footLH);
        gc.fillRect(location.getX()+86, location.getY()+118, footLW, footLH);
        
        gc.beginPath();
	gc.setStroke(Paint.valueOf(outlineColor));
	gc.setLineWidth(1);
        gc.rect(location.getX()+15, location.getY()+15, eyeLeftW, eyeLeftH);
	gc.rect(location.getX()+80, location.getY()+15, eyeLeftW, eyeLeftH);
	gc.rect(location.getX(), location.getY(), headW, headH);
	gc.stroke();
	
	// AND THEN DRAW THE REST OF HIM
    }
    
    public void renderImageRedBoxMan(Point2D location) {
	gc.drawImage(redBoxManImage, location.getX(), location.getY());
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	launch(args);
    }
    
}
