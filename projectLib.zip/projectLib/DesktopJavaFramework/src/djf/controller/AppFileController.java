package djf.controller;

import djf.ui.AppYesNoCancelDialogSingleton;
import djf.ui.AppMessageDialogSingleton;
import djf.ui.AppGUI;
import djf.components.AppDataComponent;
import java.io.File;
import java.io.IOException;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import properties_manager.PropertiesManager;
import djf.AppTemplate;
import static djf.settings.AppPropertyType.LOAD_ERROR_MESSAGE;
import static djf.settings.AppPropertyType.LOAD_ERROR_TITLE;
import static djf.settings.AppPropertyType.LOAD_WORK_TITLE;
import static djf.settings.AppPropertyType.WORK_FILE_EXT;
import static djf.settings.AppPropertyType.WORK_FILE_EXT_DESC;
import static djf.settings.AppPropertyType.NEW_COMPLETED_MESSAGE;
import static djf.settings.AppPropertyType.NEW_COMPLETED_TITLE;
import static djf.settings.AppPropertyType.NEW_ERROR_MESSAGE;
import static djf.settings.AppPropertyType.NEW_ERROR_TITLE;
import static djf.settings.AppPropertyType.SAVE_COMPLETED_MESSAGE;
import static djf.settings.AppPropertyType.SAVE_COMPLETED_TITLE;
import static djf.settings.AppPropertyType.SAVE_ERROR_MESSAGE;
import static djf.settings.AppPropertyType.SAVE_ERROR_TITLE;
import static djf.settings.AppPropertyType.SAVE_UNSAVED_WORK_MESSAGE;
import static djf.settings.AppPropertyType.SAVE_UNSAVED_WORK_TITLE;
import static djf.settings.AppPropertyType.SAVE_WORK_TITLE;
import static djf.settings.AppStartupConstants.PATH_WORK;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Optional;
import javafx.scene.control.TextInputDialog;
import javafx.stage.DirectoryChooser;

/**
 * This class provides the event programmed responses for the file controls
 * that are provided by this framework.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class AppFileController {
    // HERE'S THE APP
    AppTemplate app;
    
    // WE WANT TO KEEP TRACK OF WHEN SOMETHING HAS NOT BEEN SAVED
    boolean saved;
    
    // THIS IS THE FILE FOR THE WORK CURRENTLY BEING WORKED ON
    File currentWorkFile;

    ArrayList<File> files;
    private String currentFolderName;
    private File currentFolder;
    
    /**
     * This constructor just keeps the app for later.
     * 
     * @param initApp The application within which this controller
     * will provide file toolbar responses.
     */
    public AppFileController(AppTemplate initApp) {
        // NOTHING YET
        saved = true;
        app = initApp;
    }
    
    /**
     * This method marks the appropriate variable such that we know
     * that the current Work has been edited since it's been saved.
     * The UI is then updated to reflect this.
     * 
     * @param gui The user interface editing the Work.
     */
    public void markAsEdited(AppGUI gui) {
        // THE WORK IS NOW DIRTY
        saved = false;
        
        // LET THE UI KNOW
        gui.updateToolbarControls(saved);
    }

    /**
     * This method starts the process of editing new Work. If work is
     * already being edited, it will prompt the user to save it first.
     * 
     */
    public void handleNewRequest() {
	AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	PropertiesManager props = PropertiesManager.getPropertiesManager();
        try {
            // WE MAY HAVE TO SAVE CURRENT WORK
            boolean continueToMakeNew = true;
            if (!saved) {
                // THE USER CAN OPT OUT HERE WITH A CANCEL
                continueToMakeNew = promptToSave();
            }

            // IF THE USER REALLY WANTS TO MAKE A NEW COURSE
            if (continueToMakeNew) {
                
                ////
                Optional<String> result;
                do{
                    TextInputDialog dialog1 = new TextInputDialog();
                    dialog1.setTitle("Text Input Dialog");
                    dialog1.setHeaderText("Name of the Code Check");
                    dialog1.setContentText("Please enter the name for the code check:");

                    // Traditional way to get the response value.
                    result = dialog1.showAndWait();
                    if (result.isPresent()){
                        System.out.println("Your name: " + result.get());
                    }
                }while(checkFileName(result.get()) == false);
                setFile(result.get());
                
                ////
                
                // RESET THE WORKSPACE
		app.getWorkspaceComponent().resetWorkspace();

                // RESET THE DATA
                app.getDataComponent().resetData();
                
                // NOW RELOAD THE WORKSPACE WITH THE RESET DATA
                app.getWorkspaceComponent().reloadWorkspace(app.getDataComponent());

		// MAKE SURE THE WORKSPACE IS ACTIVATED
		app.getWorkspaceComponent().activateWorkspace(app.getGUI().getAppPane());
		
		// WORK IS NOT SAVED
                saved = false;
		currentWorkFile = null;
                
//                currentFolder = null;
                
                // REFRESH THE GUI, WHICH WILL ENABLE AND DISABLE
                // THE APPROPRIATE CONTROLS
                app.getGUI().updateToolbarControls(saved);
                app.getGUI().getWindow().setTitle("Code Check - "+result.get());
                currentFolderName = result.get();
                setWorkFolderName(currentFolderName);
                System.out.println("CWF:" + currentWorkFile+ " Result: "+currentFolderName);

                // TELL THE USER NEW WORK IS UNDERWAY
		dialog.show(props.getProperty(NEW_COMPLETED_TITLE), props.getProperty(NEW_COMPLETED_MESSAGE));
            }
        } catch (IOException ioe) {
            // SOMETHING WENT WRONG, PROVIDE FEEDBACK
	    dialog.show(props.getProperty(NEW_ERROR_TITLE), props.getProperty(NEW_ERROR_MESSAGE));
        }
    }

    /**
     * This method lets the user open a Course saved to a file. It will also
     * make sure data for the current Course is not lost.
     * 
     * @param gui The user interface editing the course.
     */
    public void handleLoadRequest() {
        try {
            // WE MAY HAVE TO SAVE CURRENT WORK
            boolean continueToOpen = true;
            if (!saved) {
                // THE USER CAN OPT OUT HERE WITH A CANCEL
                continueToOpen = promptToSave();
            }

            // IF THE USER REALLY WANTS TO OPEN A Course
            if (continueToOpen) {
                // GO AHEAD AND PROCEED LOADING A Course
                promptToOpen();
            }
        } catch (IOException ioe) {
            // SOMETHING WENT WRONG
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    PropertiesManager props = PropertiesManager.getPropertiesManager();
	    dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
        }
    }

    /**
     * This method will save the current course to a file. Note that we already
     * know the name of the file, so we won't need to prompt the user.
     * 
     * 
     * @param courseToSave The course being edited that is to be saved to a file.
     */
    public void handleSaveRequest() {
	// WE'LL NEED THIS TO GET CUSTOM STUFF
	PropertiesManager props = PropertiesManager.getPropertiesManager();
        try {
	    // MAYBE WE ALREADY KNOW THE FILE
	    if (currentWorkFile != null) {
		saveWork(currentWorkFile);
	    }
	    // OTHERWISE WE NEED TO PROMPT THE USER
	    else {
		// PROMPT THE USER FOR A FILE NAME
		FileChooser fc = new FileChooser();
		fc.setInitialDirectory(new File(PATH_WORK));
		fc.setTitle(props.getProperty(SAVE_WORK_TITLE));
		fc.getExtensionFilters().addAll(
		new ExtensionFilter(props.getProperty(WORK_FILE_EXT_DESC), props.getProperty(WORK_FILE_EXT)));

		File selectedFile = fc.showSaveDialog(app.getGUI().getWindow());
		if (selectedFile != null) {
		    saveWork(selectedFile);
		}
	    }
        } catch (IOException ioe) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
        }
    }
    
    public void handleSaveAsRequest() {
	// WE'LL NEED THIS TO GET CUSTOM STUFF
	PropertiesManager props = PropertiesManager.getPropertiesManager();
        try {
	    // MAYBE WE ALREADY KNOW THE FILE
//	    if (currentWorkFile != null) {
//		saveWork(currentWorkFile);
//	    }
	    // OTHERWISE WE NEED TO PROMPT THE USER
//	    else {
		// PROMPT THE USER FOR A FILE NAME
		FileChooser fc = new FileChooser();
		fc.setInitialDirectory(new File(PATH_WORK));
		fc.setTitle(props.getProperty(SAVE_WORK_TITLE));
		fc.getExtensionFilters().addAll(
		new ExtensionFilter(props.getProperty(WORK_FILE_EXT_DESC), props.getProperty(WORK_FILE_EXT)));

		File selectedFile = fc.showSaveDialog(app.getGUI().getWindow());
		if (selectedFile != null) {
		    saveWork(selectedFile);
//		}
	    }
        } catch (IOException ioe) {
	    AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	    dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
        }
    }
    
    // HELPER METHOD FOR SAVING WORK
    private void saveWork(File selectedFile) throws IOException {
	// SAVE IT TO A FILE
	app.getFileComponent().saveData(app.getDataComponent(), selectedFile.getPath());
	
	// MARK IT AS SAVED
	currentWorkFile = selectedFile;
	saved = true;
	
	// TELL THE USER THE FILE HAS BEEN SAVED
	AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
	PropertiesManager props = PropertiesManager.getPropertiesManager();
        dialog.show(props.getProperty(SAVE_COMPLETED_TITLE),props.getProperty(SAVE_COMPLETED_MESSAGE));
		    
	// AND REFRESH THE GUI, WHICH WILL ENABLE AND DISABLE
	// THE APPROPRIATE CONTROLS
	app.getGUI().updateToolbarControls(saved);	
    }
    
    /**
     * This method will exit the application, making sure the user doesn't lose
     * any data first.
     * 
     */
    public void handleExitRequest() {
        try {
            // WE MAY HAVE TO SAVE CURRENT WORK
            boolean continueToExit = true;
            if (!saved) {
                // THE USER CAN OPT OUT HERE
                continueToExit = promptToSave();
            }

            // IF THE USER REALLY WANTS TO EXIT THE APP
            if (continueToExit) {
                // EXIT THE APPLICATION
                System.exit(0);
            }
        } catch (IOException ioe) {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
		PropertiesManager props = PropertiesManager.getPropertiesManager();
                dialog.show(props.getProperty(SAVE_ERROR_TITLE), props.getProperty(SAVE_ERROR_MESSAGE));
        }
    }

    /**
     * This helper method verifies that the user really wants to save their
     * unsaved work, which they might not want to do. Note that it could be used
     * in multiple contexts before doing other actions, like creating new
     * work, or opening another file. Note that the user will be
     * presented with 3 options: YES, NO, and CANCEL. YES means the user wants
     * to save their work and continue the other action (we return true to
     * denote this), NO means don't save the work but continue with the other
     * action (true is returned), CANCEL means don't save the work and don't
     * continue with the other action (false is returned).
     *
     * @return true if the user presses the YES option to save, true if the user
     * presses the NO option to not save, false if the user presses the CANCEL
     * option to not continue.
     */
    private boolean promptToSave() throws IOException {
	PropertiesManager props = PropertiesManager.getPropertiesManager();
	
	// CHECK TO SEE IF THE CURRENT WORK HAS
	// BEEN SAVED AT LEAST ONCE
	
        // PROMPT THE USER TO SAVE UNSAVED WORK
	AppYesNoCancelDialogSingleton yesNoDialog = AppYesNoCancelDialogSingleton.getSingleton();
        yesNoDialog.show(props.getProperty(SAVE_UNSAVED_WORK_TITLE), props.getProperty(SAVE_UNSAVED_WORK_MESSAGE));
        
        // AND NOW GET THE USER'S SELECTION
        String selection = yesNoDialog.getSelection();

        // IF THE USER SAID YES, THEN SAVE BEFORE MOVING ON
        if (selection.equals(AppYesNoCancelDialogSingleton.YES)) {
            // SAVE THE DATA FILE
            AppDataComponent dataManager = app.getDataComponent();
	    
	    if (currentWorkFile == null) {
		// PROMPT THE USER FOR A FILE NAME
		FileChooser fc = new FileChooser();
		fc.setInitialDirectory(new File(PATH_WORK));
		fc.setTitle(props.getProperty(SAVE_WORK_TITLE));
		fc.getExtensionFilters().addAll(
		new ExtensionFilter(props.getProperty(WORK_FILE_EXT_DESC), props.getProperty(WORK_FILE_EXT)));

		File selectedFile = fc.showSaveDialog(app.getGUI().getWindow());
		if (selectedFile != null) {
		    saveWork(selectedFile);
		    saved = true;
		}
	    }
	    else {
		saveWork(currentWorkFile);
		saved = true;
	    }
        } // IF THE USER SAID CANCEL, THEN WE'LL TELL WHOEVER
        // CALLED THIS THAT THE USER IS NOT INTERESTED ANYMORE
        else if (selection.equals(AppYesNoCancelDialogSingleton.CANCEL)) {
            return false;
        }

        // IF THE USER SAID NO, WE JUST GO ON WITHOUT SAVING
        // BUT FOR BOTH YES AND NO WE DO WHATEVER THE USER
        // HAD IN MIND IN THE FIRST PLACE
        return true;
    }

    /**
     * This helper method asks the user for a file to open. The user-selected
     * file is then loaded and the GUI updated. Note that if the user cancels
     * the open process, nothing is done. If an error occurs loading the file, a
     * message is displayed, but nothing changes.
     */
    private void promptToOpen() {
        DirectoryChooser dirChooser = new DirectoryChooser();
        dirChooser.setInitialDirectory(new File(PATH_WORK));
        File dir = dirChooser.showDialog(app.getGUI().getWindow());
        
	// WE'LL NEED TO GET CUSTOMIZED STUFF WITH THIS
	PropertiesManager props = PropertiesManager.getPropertiesManager();
        
        currentFolder = dir;
            System.out.println("Before F "+ currentFolder);
            System.out.println(" Before Name "+ currentFolder.getName());
            System.out.println(" Before Directory "+ currentFolder.getAbsoluteFile());
        setWorkFolder(currentFolder.getAbsoluteFile());
        // AND NOW ASK THE USER FOR THE FILE TO OPEN
//        FileChooser fc = new FileChooser();
//        fc.setInitialDirectory(new File(PATH_WORK));
//	fc.setTitle(props.getProperty(LOAD_WORK_TITLE));
//        File selectedFile = fc.showOpenDialog(app.getGUI().getWindow());

        // ONLY OPEN A NEW FILE IF THE USER SAYS OK
        if (dir != null) { // selectedFile
            try {
                // RESET THE WORKSPACE
		app.getWorkspaceComponent().resetWorkspace();

                // RESET THE DATA
                app.getDataComponent().resetData();
                
                // LOAD THE FILE INTO THE DATA
                app.getFileComponent().loadData(app.getDataComponent(), dir.getAbsolutePath());
                
		// MAKE SURE THE WORKSPACE IS ACTIVATED
		app.getWorkspaceComponent().activateWorkspace(app.getGUI().getAppPane());
                
                // AND MAKE SURE THE FILE BUTTONS ARE PROPERLY ENABLED
                saved = true;
                app.getGUI().updateToolbarControls(saved);
                
                app.getGUI().getWindow().setTitle("Code Check - "+ dir.getName());
                currentFolderName = dir.getName();
                currentFolder = dir;
                setWorkFolderName(currentFolderName);
//                setWorkFolder(currentFolder);
                System.out.println("Directory: "+ currentFolder +" opened " + currentFolder.getPath());
                
            } catch (Exception e) {
                AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
                dialog.show(props.getProperty(LOAD_ERROR_TITLE), props.getProperty(LOAD_ERROR_MESSAGE));
            }
        }
    }

    /**
     * This mutator method marks the file as not saved, which means that when
     * the user wants to do a file-type operation, we should prompt the user to
     * save current work first. Note that this method should be called any time
     * the course is changed in some way.
     */
    public void markFileAsNotSaved() {
        saved = false;
    }

    /**
     * Accessor method for checking to see if the current work has been saved
     * since it was last edited.
     *
     * @return true if the current work is saved to the file, false otherwise.
     */
    public boolean isSaved() {
        return saved;
    }
    
    public void setFile(String s)
    {
        try{
            String strDirectoy = s;
            String strDirectoy1 = "blackboard";
            String strDirectoy2 = "code";
            String strDirectoy3 = "projects";
            String strDirectoy4 = "submissions";
            
            // Create one directory   PATH_WORK
            currentFolder = new File( "work\\"+ strDirectoy);
            System.out.println("Before F "+ currentFolder);
            System.out.println(" Before Name "+ currentFolder.getName());
            System.out.println(" Before Directory "+ currentFolder.getAbsoluteFile());
            setWorkFolder(currentFolder.getAbsoluteFile());
            setWorkFolderName(currentFolder.getName());
            boolean success = ( currentFolder ).mkdir();
//            currentFolder. = currentFolder.getPath().replace(".", "");
            if (success) {System.out.println("Directory CF: "+ currentFolder+" D:"+ strDirectoy + " created " + currentFolder.getAbsoluteFile());}  
                // Create multiple directories
            success = (new File(PATH_WORK + strDirectoy +"/" + strDirectoy1)).mkdirs();
//            if (success) {System.out.println("Directory: "+ strDirectoy1 + " created");}
            success = (new File(PATH_WORK + strDirectoy +"/" + strDirectoy2)).mkdirs();
//            if (success) {System.out.println("Directory: "+ strDirectoy2 + " created");}
            success = (new File(PATH_WORK + strDirectoy +"/" + strDirectoy3)).mkdirs();
//            if (success) {System.out.println("Directory: "+ strDirectoy3 + " created");}
            success = (new File(PATH_WORK + strDirectoy +"/" + strDirectoy4)).mkdirs();
//            if (success) {System.out.println("Directory: "+ strDirectoy4 + " created");}
            
        }catch (Exception e){//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    public boolean checkFileName(String s){
        try{
//        files = new ArrayList<File>();
        File repo = new File (PATH_WORK);
        String path = ".\\work\\"+s;
        File[] fileList = repo.listFiles();
        
        for (int i=0; i<fileList.length; i++) {
//            System.out.println("File N" + i +" is: "+ fileList[i].getName());
            if(path.equals(fileList[i].toString())){
                return false;
            }
        }
        return true;
        }
        catch(Exception murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = "Error Message"; // props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = "Error in CheckFileName"; // props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
        return true;
    }
    
    public void handleRename(){
        Optional<String> result;
        do{
            TextInputDialog dialog1 = new TextInputDialog();
            dialog1.setTitle("Text Input Dialog");
            dialog1.setHeaderText("Rename of the Code Check");
            dialog1.setContentText("Please enter a new name for the "+ app.getGUI().getWindow().getTitle() +" : ");
            // Traditional way to get the response value.
            result = dialog1.showAndWait();
            if (result.isPresent()){
                System.out.println("Your name: " + result.get());
            }
        }while(checkFileName(result.get()) == false );
        
        File oldName = new File(PATH_WORK + currentFolderName); // getWorkFolder();
        File newName = new File("work\\" + result.get());
        
            System.out.println("Before NF "+ newName);
            System.out.println(" Before NName "+ newName.getName());
            System.out.println(" Before NDirectory "+ newName.getAbsoluteFile());
        
        app.getGUI().getWindow().setTitle("Code Check - "+result.get());
        
        System.out.println(" new: " + newName.getName() +" path: "+ newName.getPath()+" A Path: "+ newName.getAbsolutePath()+" A file: "+ newName.getAbsoluteFile());
        System.out.println(" old: " + getWorkFolder() );//+" path: "+ oldName.getPath()); // "old: "+ oldName.getName() +
        
        if (getWorkFolder().renameTo(newName.getAbsoluteFile())) {
        System.out.println("renamed");
        System.out.println(" new: " + newName.getName() +" path: "+ newName.getPath()+" A Path: "+ newName.getAbsolutePath());
        } else {
         System.out.println("still");
        }
    }
    
    public void setWorkFolder(File f){
        currentFolder = f;
    }
    
    public File getWorkFolder(){
        return currentFolder;
    }
    public void setWorkFolderName(String f){
        currentFolderName = f;
    }
    
    public String getWorkFolderName(){
        return currentFolderName;
    }
    
    public void setTableElement(String s, File f){
        //
    }
    
        public void displayFileName(String f, String s){
        try{
//        files = new ArrayList<File>();
        System.out.println("displayFileName PART");
        File repo1 = new File (f);
//        String path = ".\\work\\"+s;
        File[] fileList1 = repo1.listFiles();
        
        for (int i=0; i<fileList1.length; i++) {
            System.out.println("File N" + i +" is: "+ fileList1[i].getName());
//            if(path.equals(fileList[i].toString())){
//                return false;
//            }
        }
//        return true;
        }
        catch(Exception murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = "Error Message"; // props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = "Error in CheckFileName"; // props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
//        return true;
    }
    
}
